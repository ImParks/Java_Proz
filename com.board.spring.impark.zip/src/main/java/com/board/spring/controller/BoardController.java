package com.board.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.board.spring.dto.Dto;
import com.board.spring.service.BoardService;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

	@Log4j
	@RequestMapping("/board/*")
	//@AllArgsConstructor
	@Controller
	public class BoardController{
			
		@Setter(onMethod_ = @Autowired)
		private BoardService service;
		
		@GetMapping("/list")
		public String postlist(Model model) {
			model.addAttribute("list",service.postNoList());
			return"/list";
		}
		@GetMapping({"/read"})
		public String postRead(@RequestParam("postNumber")String postNumber,Model model) { 
			model.addAttribute("postInfo",service.postInfo(postNumber));
			return "/read";
		}
		
		@GetMapping({"/modify"})
		public String modifyPage(@RequestParam("postNumber")String postNumber,Model model) { 
			model.addAttribute("postInfo",service.postInfo(postNumber));
			return "/modify";
		}
		
		@PostMapping("/modify")
		public String postModify(Dto postModify) {
		
			service.postModify(postModify);
			return"redirect:/board/read?postNumber="+postModify.getPostNumber();
		}
		
		@GetMapping("/del")
		public String postDel(@RequestParam("postNumber")String postNumber) {
			service.postDel(postNumber);
			return"redirect:/board/list";
		}

		
		
}
