package com.board.spring.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.board.spring.dto.Dto;
import com.board.spring.mapper.Mapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;


@Log4j
@Service
public class BoardServiceImpl implements BoardService{

	@Setter(onMethod_ = @Autowired)
	private Mapper mapper;	
	
	@Override
	public ArrayList<Dto> postNoList() {
		return mapper.postNoList();
		
		
	}
	
	@Override
	 public Dto postInfo(String postNumber) {
		 return mapper.postInfo(postNumber);
		 
	 }
	 
	@Override
	 public Dto userInfo(String userInfo) {
		 return mapper.userInfo(userInfo);
	 }
	
	@Override
	public void postModify(Dto postModifyr) {
		mapper.postModify(postModifyr);
	}
	
	@Override
	 public void postDel(String postNumber) {
		mapper.postDel(postNumber);
	}
	
	
}
