package com.board.spring.service;

import java.util.ArrayList;

import com.board.spring.dto.Dto;



public interface BoardService {
 public ArrayList<Dto> postNoList();
 public Dto postInfo(String postNumber);
 public Dto userInfo(String userInfo);
 public void postModify(Dto postModify);
 public void postDel(String postNumber);
 
}
