package com.board.spring.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;

import com.board.spring.service.BoardService;

import lombok.Setter;

public class Util {

	@Setter(onMethod_ = @Autowired)
	private BoardService service;

	
	public void userInfo(String userInfo,Model model) {
		model.addAttribute("userInfo",service.userInfo(userInfo));	
	}
	
}
