package com.board.spring.dto;

import lombok.Data;

@Data
public class Dto {

	private String postNumber;
	private String title;
	private String content;
	private int hit;
	private int userNumber;
	private String userName;
	private int userTag;
	private String dateTime;
	private String upDateTime;
	
}