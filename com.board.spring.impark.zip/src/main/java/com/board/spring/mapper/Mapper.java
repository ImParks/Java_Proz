package com.board.spring.mapper;

import java.util.ArrayList;

import com.board.spring.dto.Dto;

public interface Mapper {
	
	 public ArrayList<Dto> postNoList();
	 public Dto postInfo(String postNumber);
	 public Dto userInfo(String userInfo);
	 public void postModify(Dto postModify);
	 public void postDel(String postNumber);
}