package com.MangoChat.util;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.MangoChat.LoginDB.L_Dto;
import com.MangoChat.MasterClass.Master_DA;
import com.MangoChat.MasterClass.Master_DB;
import com.MangoChat.RoomDB.R_Dto;

public class Util extends Master_DA {

	public L_Dto userName(String userNo) { // 닉네임 테그 구하는함수
		L_Dto name = null;
		String sql = String.format("SELECT * FROM %s WHERE userNo = %s", Master_DB.DB_TABLE_LOGIN, userNo);
		try {
			ResultSet rs = super.Query(sql);
			rs.next();
			name = new L_Dto(rs.getString("userName"), rs.getString("userTag"));
		} catch (Exception e) {
			System.out.println(sql);
			e.printStackTrace();
		} finally {
			close();
		}
		return name;
	}
	
	public int roomUserCount(String roomNo) { //현제 인원넘버
		int count = 0;
		String sql = String.format("SELECT COUNT(*) FROM %s WHERE roomNo = %s", DB_TABLE_JOIN, roomNo);
		try {
			ResultSet rs = super.Query(sql);
			rs.next();
			count = rs.getInt("COUNT(*)");
		} catch (Exception e) {
			System.out.println(sql);
			e.printStackTrace();
		} finally {
			close();
		}
		return count;
	}
	
	public int max(String roomNo) { // 방의 최대 인원수 구해주는 함수
		int max = 0;
		String sql = String.format("SELECT * FROM %s WHERE roomNo = %s",DB_TABLE_ROOM,roomNo);
		try {
			ResultSet rs = Query(sql);
			rs.next();
			max = rs.getInt("userMax");
		}catch (SQLException e) {
			System.out.println(sql);
			e.printStackTrace();
		}finally {
			close();
		}
		return max;
	}
	
	public String userNo(String name,String tag) {
		String userNo = null;
		String sql = String.format("SELECT * FROM %s WHERE userName = '%s' and userTag = %s",DB_TABLE_LOGIN,name,tag);
		try {
		ResultSet rs = Query(sql);
		rs.next();
		userNo = rs.getString("userNo");
		} catch (SQLException e) {
			System.out.println(sql);
			e.printStackTrace();
		} finally {
			close();
		}
		return userNo;
	}
	
	public R_Dto roomInfo(String roomNo) {
		R_Dto info = null;
		String sql = String.format("SELECT * FROM %s WHERE roomNo = %s",DB_TABLE_ROOM,roomNo);
		try {
			ResultSet rs = Query(sql);
			rs.next();
			info = new R_Dto(rs.getString(""),);
//			초대한 사람, 방이름 , 방장이름, 현제인원, 최대인원 이거 해야함..꼭 
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			close();
		}
		return info;
	}
}
