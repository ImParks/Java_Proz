package CharacterPackage;

public class LoadObj {

	public static String myNpcID; //<- 객채
	public static int myNpcNo; //<- 객채
	public static MonsterObj Mons = new MonsterObj();

	
	
}