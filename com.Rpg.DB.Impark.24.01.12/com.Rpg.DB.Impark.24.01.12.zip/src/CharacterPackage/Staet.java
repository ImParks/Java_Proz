package CharacterPackage;

import DataBase.NpcDB;
import FunctionPackage.So;
import FunctionPackage.TextBox;

public class Staet {

	public static void staet() {
		end:
		while (true) {
			
			NpcObj.npcInfo();
			if (NpcDB.npcLoad("N_staet") > 0) {
				So.ln("잔여스텟이 있습니다.");
				So.line();
				So.ln("| 1 : STR | 2: DEX | 3:INT | 4: LUK |");
				So.line();
			}
			TextBox.cmd = TextBox.r("입력");

			if (NpcDB.npcLoad("N_staet") > 0) {
	
				switch (TextBox.cmd) {
				case "1":
					NpcDB.save("N_str = N_str + 1 , N_MaxHp = N_MaxHp + 10 , N_staet = N_staet - 1");
					
					break;
				case "2":
					NpcDB.save("N_dex = N_dex + 1 , N_staet = N_staet - 1");
					
					break;
				case "3":
					NpcDB.save("N_inte = N_inte + 1 , N_staet = N_staet - 1");
					
					break;
				case "4":
					NpcDB.save("N_luk = N_luk + 1 , N_staet = N_staet - 1");
					
					break;
				case "0":
					So.ln("스텟창을 닫습니다.");
					break end;

				default:
					So.ln("잘못된 입력입니다.");
					break;
				}

			} else {
					break end;

			}
		}

	}

}
