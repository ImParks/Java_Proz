package CharacterPackage;

import DataBase.NpcDB;
import FunctionPackage.So;

public class NpcObj {

	public static void npcInfo() {
		So.title("상태창");
		So.ln("[ 닉네임:" + NpcDB.npcLoad("N_name","") + "]");
		So.ln("[ 성별:" + NpcDB.npcLoad("N_sex","") + "]");
		So.ln("[ 레벨:" + NpcDB.npcLoad("N_level") + "]");
		So.ln("[ 경험치:" + NpcDB.npcLoad("N_exp") +"/" + NpcDB.npcLoad("N_maxExp") + "]");
		So.ln("[ 체력:" + NpcDB.npcLoad("N_hp") + "/ " + NpcDB.npcLoad("N_MaxHp") + "]");
		So.ln("[GOLD :" + NpcDB.npcLoad("N_gold") + "g]");
		So.tit("스텟");
		So.ln("[ STR :" + NpcDB.npcLoad("N_str") + "]"); // 공격력, 체력 증가
		So.ln("[ DEX :" + NpcDB.npcLoad("N_dex") + "]"); // 연속 공격확률, 회피 확률 증가
		So.ln("[ INT :" + NpcDB.npcLoad("N_inte") + "]"); // 기습 확률 감소<- 내가 받는 피해가 크리티컬임, 반격 확률 감소<- 무조건 크리티컬임
		So.ln("[ LUK :" + NpcDB.npcLoad("N_luk") + "]"); // 보상증가, 크리티컬 확률 증가
		So.ln("[ 잔여스텟 :" + NpcDB.npcLoad("N_staet") + "]");
		So.line();
	}
	
	public static void npcBattlInfo(){
		So.tit("상태창");
		So.t("[닉네임:" + NpcDB.npcLoad("N_name","") +"]");
		So.t("[레벨:" +  NpcDB.npcLoad("N_level") +"]");
		So.t("[체력:" + NpcDB.npcLoad("N_hp") +"/" +  NpcDB.npcLoad("N_MaxHp") +"]");
		So.line();
	}

	public static void levelUp(){
		int exp = NpcDB.npcLoad("N_exp");
		int max = NpcDB.npcLoad("N_MaxExp");
		if(exp >=  max) {
			NpcDB.save("N_exp = N_exp - "+ max);
			NpcDB.save("N_MaxExp = N_MaxExp * 1.2");
			So.t(NpcDB.npcLoad("N_level") + " => ");
			NpcDB.save("N_level = N_level+1");
			So.ln(NpcDB.npcLoad("N_level")+"");
			NpcDB.save("N_staet = N_staet + 3");
			So.ln("플레이어가 레벨업하였습니다");
			
		}
	}
	
	public static String way(String a) {
		String ck = a;
		if (ck.equals("W")  || ck.equals("ㅈ")){
			ck = "w";
		}
		if (ck.equals("A")  || ck.equals("ㅁ")){
			ck = "w";
		}
		if (ck.equals("S")  || ck.equals("ㄴ")){
			ck = "w";
		}
		if (ck.equals("D")  || ck.equals("ㅇ")){
			ck = "w";
		}

		return ck;
	}


	
	
}
