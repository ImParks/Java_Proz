package CharacterPackage;

import FunctionPackage.So;

public class MonsterObj {
	
	public String name;
	public int hp;
	public int maxHp;
	public int atk;
	public int gold;
	public int exp;
	public int no;
	public MonsterObj(){
		this.no = 0;
		this.name = null;
		this.hp = 0;
		this.maxHp = 0;
		this.atk = 0;
		this.gold = 0;
		this.exp = 0;
	}
	
	public void infoMonster(){
		So.lin();
		So.ln("[" + name + "]");
		So.ln("[" + hp +"/" + maxHp +"]");
		So.lin();
	}
	
	
}
