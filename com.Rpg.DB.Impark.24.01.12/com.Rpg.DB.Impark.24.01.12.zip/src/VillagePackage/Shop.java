package VillagePackage;

import FunctionPackage.So;
import FunctionPackage.TextBox;

public class Shop {

	public static void shop() {
	while (true) {
		So.ln("1번 구매, 2번 판매, 0번 뒤로가기");
		TextBox.cmd = TextBox.r("입력");
		switch (TextBox.cmd) {
		case "1": //구매
			
			break;
		case "2": // 판매
			
			break;
		case "0":
			
			break;
		default:
			So.ln("올바른 입력이 아닙니다.");
			break;
		}
		
	}
		
		
	}
	
}
