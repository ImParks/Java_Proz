package VillagePackage;

import DataBase.NpcDB;
import FunctionPackage.So;
import FunctionPackage.TextBox;

public class Pub {

	public static void pub() {
		So.ln("여관에 들어왔다.");

	
		So.ln("["+ NpcDB.npcLoad("N_gold") + "g]");
		So.ln("1 :  잠을잔다(체력 회복) -300g || 0 : 뒤로가기") ;
		end:
		while (true) {
			TextBox.cmd = TextBox.r("입력");
			switch (TextBox.cmd) {
			case "1":
				if( NpcDB.npcLoad("N_gold") >= 300) {
				NpcDB.save("N_hp = N_MaxHp");
				NpcDB.save("N_gold = N_gold - 300");
				So.ln("푹 쉬고 일어났더니 몸이 개운하다");
				}  else {
					So.ln("여관주인 : 돈도없는 거지 xx 가 어딜 들어와 썩 꺼져");
				}
				break end;
			case "0":
				So.ln("여관주인 : 재수 없는 자식 길가다 똥이나 밟아라");
				break end;

			default:
				So.ln("여관주인 : 어떤 용무로 오셨나요.");
				break;
			}
			
			

			
		}
	
		
	}
	
	
}
