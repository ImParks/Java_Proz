package RpgPackage;

import BattlePackage.BattleStart;
import CharacterPackage.LoadObj;
import DataBase.DataBase;
import FunctionPackage.So;
import MapPackage.MapLoadObj;
import MapPackage.MapObj;
import VillagePackage.Village;

public class Active {

	public static void active() {
		String villName = null;
		boolean ck = false;
		
		int npcX = DataBase.dbExecuteQuery("SELECT * FROM Npc WHERE N_no = '" + LoadObj.myNpcNo + "';","N_x",0);
		int npcY = DataBase.dbExecuteQuery("SELECT * FROM Npc WHERE N_no = '" + LoadObj.myNpcNo + "';","N_y",0);
		
		for (MapObj p : MapLoadObj.map) {
			if (npcX == p.x ) {
				if(npcY == p.y) {
					villName = p.name;
					ck = true;
				}
			}
		}
		if(ck) {
			So.ln(villName + "에 도착하였습니다.");
			Village.village();
		} else {
			BattleStart.battleStart();
		}
		
//		

	}

}
