package RpgPackage;

import CharacterPackage.NpcObj;
import FunctionPackage.So;
import FunctionPackage.TextBox;
import MapPackage.Movement;

public class Move {


	public static void move() {

		end:
		while (true) {
			So.ln("          W : 전진");
			So.ln(" A : 왼쪽, S : 후진, D : 오른쪽");
			String text= TextBox.rl("이동");
			String a = NpcObj.way(text);
			System.out.println(a + "");
			switch(a) {
			case "w":
				Movement.straight();
				break;
			case "a" :
				Movement.left();
				break;
			case "s" :
				Movement.junior();
				break;
			case "d" :
				Movement.right();
				break;
			case "0" :
				
				break end;
			
			
			
			
			}
			
			
		}
		
	}
	
}
