package NpcPackage;

import CharacterPackage.LoadObj;
import DataBase.DataBase;
import DataBase.NpcDB;
import FunctionPackage.So;
import FunctionPackage.TextBox;

public class NpcDel {

	public static void npcDel() {
		boolean npcCk = false;

		int cmd = 0;
		int myNpcCount = NpcDB.count();

		if (myNpcCount > 0) {
			npcCk = NpcDB.npcList(myNpcCount);
		} else {
			So.ln("캐릭터 없음");
		}
		if (npcCk) {
			end: while (true) {
				So.ln("0 : 뒤로가기");
				cmd = TextBox.wh("입력");

				if (cmd == 0) {
					break;
				}
				int delNpc = NpcDB.myNpcNo(myNpcCount, cmd);
				if (delNpc != 0) {
					So.ln("정말로 캐릭터를 삭제하겠습니까?");
					So.ln("1 : YES || 2 : NO");
					TextBox.cmd = TextBox.rl("선택");
					switch (TextBox.cmd) {
					case "1":
						So.ln("캐릭터를 삭제합니다.");
						So.ln(cmd+"");
						String x = String.format("DELETE FROM Npc WHERE N_ID  = '" + LoadObj.myNpcID + "' AND N_number = " + cmd);
						So.ln(LoadObj.myNpcID);
						DataBase.dbExecuteUpdate(x);
						So.ln("캐릭터 삭제 완료");
						break end;
					case "2":
						So.ln("캐릭터 삭제를 취소합니다.");
						return;
					default:
						So.ln("올바르지 않은 입력입니다.");
						return;
					}
				} else {
					So.ln("해당 번호에 캐릭터가 없습니다..");
				}
			}

		}
	}
}
