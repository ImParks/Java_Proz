package NpcPackage;

import CharacterPackage.LoadObj;
import DataBase.NpcDB;
import FunctionPackage.So;
import FunctionPackage.TextBox;
import RpgPackage.World;

public class NpcList {

	public static void npcList() {
		boolean ckNpc = false;
		boolean ckNum = false;
		int cmd = 0;
		int myNpcCount = NpcDB.count();

		if (myNpcCount > 0) {
			ckNpc = NpcDB.npcList(myNpcCount);
		} else {
			So.ln("캐릭터 없음");
		}
		if (ckNpc) {
			end: while (true) {
				cmd = TextBox.wh("입력");
				if (NpcDB.myNpcNo(myNpcCount, cmd) != 0) {
					LoadObj.myNpcNo = NpcDB.myNpcNo(myNpcCount, cmd);
					ckNum = true;
					break end;
				} else if(cmd == 0){
					So.ln("뒤로가기");
					return;
				} else {
					So.ln("해당 번호에 캐릭터가 없습니다..");
				}
			}
		}
		if (ckNum) {
			World.world();
		}
	}
}