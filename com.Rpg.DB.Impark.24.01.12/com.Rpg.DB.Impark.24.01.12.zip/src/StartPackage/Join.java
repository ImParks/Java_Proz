package StartPackage;

import DataBase.LoginDB;
import FunctionPackage.So;
import FunctionPackage.TextBox;

public class Join {
	public static void join() {

		So.title("회원가입");

		String id; // 아이디 입력

		while (true) {
			id = TextBox.makeJoin("ID"); // 아이디 입력

			if (LoginDB.log(id)) {
				break;
			} else {
				So.ln("중복된 아이디가 있습니다.");
			}
		}

		String pw = TextBox.makeJoin("PW");
		LoginDB.join(id, pw);

		So.ln("작성이 완료되었습니다.");

	}
}
