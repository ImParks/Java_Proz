package StartPackage;

import CharacterPackage.LoadObj;
import DataBase.LoginDB;
import FunctionPackage.So;
import FunctionPackage.TextBox;

public class Login {

	public static void login() {
		String text = "아이디";
		So.title("로그인");
		So.ln("아이디를 입력해주세요");
		// 아이디를 입력해주세요,
		String id = TextBox.r("ID");
		// 비밀번호를 입력해주세요,
		String pw = TextBox.r("PW");
		// 입력한 아이디 비밀번호 조회
		if (!LoginDB.log(id)) {
			text = "비밀번호";
		}
		if (!LoginDB.log(id, pw)) {
			LoadObj.myNpcID = id;
			Home.home();
		} else {
			So.ln(text + "를 잘못 입력했습니다.");
		}
	}
}
