package MapPackage;

import java.util.ArrayList;

import FunctionPackage.So;

public class MapLoadObj {

	public static ArrayList<MapObj> map = new ArrayList<>();
	
	
 
	public static void vill(String a, int xCk) {
		if (xCk < 4) {
			So.t(a);
		} else {
			So.ln(a);
		}
	}
}
