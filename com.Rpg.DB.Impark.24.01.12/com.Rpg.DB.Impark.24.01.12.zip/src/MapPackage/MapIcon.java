package MapPackage;

public class MapIcon {

	
	public static void village(int x, int y, int xCk) {
		String home = "★";
		String ground = "□";
		boolean ck = false;

		for (MapObj mapCk : MapLoadObj.map) {
			if (x == mapCk.x && y == mapCk.y) {
				ck = true;
			}
					}

		if (ck) {
			MapLoadObj.vill(home, xCk);
		} else {
			MapLoadObj.vill(ground, xCk);
		}

	}

}
