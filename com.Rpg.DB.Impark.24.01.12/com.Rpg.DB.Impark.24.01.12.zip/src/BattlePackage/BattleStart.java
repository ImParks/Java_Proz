package BattlePackage;

import CharacterPackage.LoadObj;
import DataBase.MonsterDB;
import FunctionPackage.Random;
import FunctionPackage.So;

public class BattleStart {

	public static void battleStart() {

		MonsterDB.spawn();
		int a = Random.random();
		if(a < 5) {

			Surprise.monsterSurprise();
			LoadObj.Mons.infoMonster();
			So.ln("몬스터에게 기습당하였습니다.");
			So.lin();
			BattlePage.battle();
		} else if(a < 40) {
			LoadObj.Mons.infoMonster();
			So.ln("몬스터를 발경하였습니다.");
			BattlePage.battle();
		} else if(a < 50) {

			LoadObj.Mons.infoMonster();
			Surprise.surprise();
			So.ln("플레이어가 몬스터를 먼저 발견하여 기습공격 하였습니다.");
			So.lin();
			BattlePage.battle();
		} else {
			So.ln("위협이 될만한것을 발견하지 못했습니다.");
		}
	}
	
}
