package BattlePackage;

import CharacterPackage.LoadObj;
import CharacterPackage.NpcObj;
import DataBase.NpcDB;
import FunctionPackage.So;

public class Win {

	public static void win() {
		
		int dropGold = LoadObj.Mons.gold + (int) (LoadObj.Mons.gold * (NpcDB.npcLoad("N_luk")*0.02)) ;
		int dropExp = LoadObj.Mons.exp + (int) (LoadObj.Mons.exp * (NpcDB.npcLoad("N_luk")*0.02));
		// 전투에서 승리하였습니다.
		So.line();
		So.ln("전투에서 승리하였습니다.");
		So.lin();
		So.ln("전투에서 승리하여[" + dropGold + "g] [" + dropExp + "Exp ] 를 얻었습니다.");
		NpcDB.save("N_exp = N_exp + " + dropExp);
		NpcObj.levelUp();
		
	}
	
}
