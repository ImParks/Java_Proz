package BattlePackage;

import DataBase.NpcDB;
import FunctionPackage.So;

public class Lose {

	public static void lose() {
		int loseExp = NpcDB.npcLoad("N_MaxHp") / 5;

		// 전투에서 패배하였습니다.
		So.line();
		So.ln("전투에서 패배하였습니다.");
		So.lin();
		So.ln("전투에서 패배하여 [" + loseExp + "] 를 잃었습니다.");

		NpcDB.save("N_exp = N_exp - " + loseExp);

		if (NpcDB.npcLoad("N_exp") <= 0) {

			NpcDB.save("N_exp =0");

		}
	}

}
