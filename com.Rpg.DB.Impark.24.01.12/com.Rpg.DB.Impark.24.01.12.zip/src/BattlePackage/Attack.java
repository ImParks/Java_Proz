package BattlePackage;

import CharacterPackage.LoadObj;

public class Attack {

	public static void attack() {

		// 플레이어가 공격
		NpcAtk.npcAtk("");
		// 몬스터가 공격
		if (LoadObj.Mons.hp > 0) {
			MonsterAtk.monsterAtk("");
		}

	}

}
