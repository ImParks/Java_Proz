package BattlePackage;

import CharacterPackage.LoadObj;
import DataBase.NpcDB;
import FunctionPackage.Random;
import FunctionPackage.So;

public class NpcAtk {

	public static void npcAtk(String sur) {
		int npcDps = NpcDB.npcLoad("N_str");
		int luk = NpcDB.npcLoad("N_luk");
		int dex = NpcDB.npcLoad("N_dex");
		String text = sur;
		int monsterDps = LoadObj.Mons.atk;
		if (Random.random() < 30 + luk * 0.1) {
			npcDps = npcDps * 2;
			text = "치명적인 " + text;
		}
		// 플레이어가 공격 연속공격도 함
		if (Random.random() > 5 + dex * 0.1) {
			text = text + " 5회";
			npcDps = npcDps * 5;
			System.out.println();
			LoadObj.Mons.hp = LoadObj.Mons.hp - npcDps;
		} else if (Random.random() > 10 + dex * 0.1) {
			text = text + " 3회";
			npcDps = npcDps * 3;
			LoadObj.Mons.hp = LoadObj.Mons.hp - npcDps;
		} else if (Random.random() > 30 + dex * 0.1) {
			text = text + " 2회";
			npcDps = npcDps * 2;
			LoadObj.Mons.hp = LoadObj.Mons.hp - npcDps * 2; 
		} else {
			LoadObj.Mons.hp = LoadObj.Mons.hp - npcDps;
		}
		System.out.println(npcDps);
		So.ln("플레이어가 몬스터에게 " + text + "공격하였습니다.");
		So.ln("몬스터는 [" + npcDps + "]의 피해를 받았습니다.");

		// 몬스터가반격
		if (Random.random() > 20) {
			NpcDB.save("N_hp = N_hp - " + monsterDps) ;
			So.ln("몬스터가 반격하였습니다.");
			So.ln("플레이어는 [" + monsterDps + "] 의 피해를 받았습니다.");

		}

	}

}

