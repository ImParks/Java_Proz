package BattlePackage;

import CharacterPackage.LoadObj;
import DataBase.NpcDB;
import FunctionPackage.Random;
import FunctionPackage.So;

public class MonsterAtk {

	public static void monsterAtk(String sur) {

		int npcDps = NpcDB.npcLoad("N_str");
		int monsterDps = LoadObj.Mons.atk;
		// 플레이어가 공격 당함
		NpcDB.save("N_hp = N_hp - " + monsterDps);
		So.ln("몬스터가 플레이어를 " + sur + "공격하였습니다.");
		So.ln("플레이어는 [" + monsterDps + "]의 피해를 받았습니다.");

		// 플레이어가 반격
		if (!sur.equals("기습")) {
			if (Random.random() > 30) {
				LoadObj.Mons.hp = LoadObj.Mons.hp - npcDps;
				So.ln("플레이어가 반격하였습니다.");
				So.ln("몬스터는 [" + npcDps + "] 의 피해를 받았습니다.");
			}
		}

	}
}