package BattlePackage;


public class Surprise {

	public static void surprise() {
		NpcAtk.npcAtk("기습");
		
	}
	
	public static void monsterSurprise() {
		MonsterAtk.monsterAtk("기습");
	}
	
	
	
}
