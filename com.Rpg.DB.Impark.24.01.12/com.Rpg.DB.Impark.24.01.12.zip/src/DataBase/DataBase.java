package DataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DataBase {
	public static Connection con = null;
	public static Statement st = null;
	public static ResultSet result = null;
	public static void run() {
		dbInit("Rpg");
		VillageDB.mapLoad();
	}
	// 기본 연결 시작시 하는게 좋음
	public static void dbInit(String a) {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + a, "root", "root");
			st = con.createStatement(); // Statement는 정적 SQL문을 실행하고 결과를 반환받기 위한 객체다. Statement하나당 한개의 ResultSet 객체만을 열
										// 수있다.
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}

	// 결과 출력하는 함수
	public static String dbExecuteQuery(String query, String a, String q) {
		String text = q;
		try {
			result = st.executeQuery(query);
			while (result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				text = result.getString(a); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				return text;
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
		return text;
	}

	// 숫자 출력하는 함수
	public static int dbExecuteQuery(String query, String a, int q) {

		try {
			result = st.executeQuery(query);
			while (result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				int max = result.getInt(a); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				return max;
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
		return q;
	}

	// 카운트 하는 함수
	public static int dbExecuteQuery(String query, int a) {

		try {
			result = st.executeQuery(query);
			while (result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				int max = result.getInt(a); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				return max;
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
		return a;
	}

	// 카운트 반환
	public static int dbExecuteQuery(String query) {
		int max = 0;
		try {
			result = st.executeQuery(query);
			while (result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				max = result.getInt(1); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				return max;
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
		return max;
	}
	// 중복확인
	public static boolean dbExecuteQuery(String query,boolean ck) {
		boolean ak = ck;
		try {
			result = st.executeQuery(query);
			while (result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				int max = result.getInt("count(*)"); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				if(max == 0) {
					ak = true;
				}
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());

		}
		return ak;
	}

	// 데이터 저장하는 함수
	public static void dbExecuteUpdate(String query) {
		try {
			st.executeUpdate(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
}
