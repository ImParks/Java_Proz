package DataBase;

public class LoginDB {

	public static boolean log(String id) {

		return DataBase.dbExecuteQuery("SELECT COUNT(*) FROM Login WHERE L_ID = '" + id + "';", false);

	}

	public static boolean log(String id, String pw) {

		return DataBase.dbExecuteQuery("SELECT COUNT(*) FROM Login WHERE L_ID = '" + id + "'and L_pw = '" + pw + "';",
				false);

	}

	public static void join(String id, String pw) {

		DataBase.dbExecuteUpdate("INSERT INTO Login(L_ID,L_PW) VALUE ('" + id + "','" + pw + "');");
	}
}
