package DataBase;

import CharacterPackage.LoadObj;

public class MonsterDB {

	public static void spawn() {
		
		LoadObj.Mons.no = monsterLoad("M_no");
		LoadObj.Mons.name = monsterLoad("M_name","");
		LoadObj.Mons.hp = monsterLoad("M_hp");
		LoadObj.Mons.maxHp = monsterLoad("M_MaxHp");
		LoadObj.Mons.atk = monsterLoad("M_atk");
		LoadObj.Mons.gold = monsterLoad("M_gold");
		LoadObj.Mons.exp = monsterLoad("M_exp");
	
	}
	
	public static int monsterLoad(String a) {
		return DataBase.dbExecuteQuery("SELECT * FROM Monster WHERE M_no = 1;",a,0);
	}
	public static String monsterLoad(String a, String b) {
		String ck=b;
		return DataBase.dbExecuteQuery("SELECT * FROM Monster WHERE M_no = 1;",a,ck);
	}
	
}
