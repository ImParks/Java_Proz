package com.peisia.mapper;

import java.util.ArrayList;

import com.peisia.spring.dto.LogInfo;
import com.peisia.spring.dto.chatGptDto.Choice;

public interface ChatGptMapper {

	public ArrayList<LogInfo> chatingLog();
	public ArrayList<LogInfo> chating();
	public int count();
	public void userChating(String mag);
	public void systemChating(Choice log);
}
