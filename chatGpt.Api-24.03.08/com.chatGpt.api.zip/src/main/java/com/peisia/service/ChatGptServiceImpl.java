package com.peisia.service;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.peisia.mapper.ChatGptMapper;
import com.peisia.spring.dto.LogInfo;
import com.peisia.spring.dto.SearchDto;
import com.peisia.spring.dto.chatGptDto.ChatGpt;
import com.peisia.spring.dto.chatGptDto.Choice;
import com.peisia.spring.dto.chatGptDto.Message;

import lombok.Setter;

@Service
public class ChatGptServiceImpl implements ChatGptService{
	
	
	@Setter(onMethod_ = @Autowired)
	private ChatGptMapper mapper;
	
	private final String API_KEY = "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";
	private final String API_URL = "https://api.openai.com/v1/chat/completions";
    private RestTemplate restTemplate;
    private HttpHeaders headers;
    JSONObject jsonObj = new JSONObject();
    
	public ArrayList<LogInfo> chating(SearchDto mag) {
		// 질문 먼저 sql에 인설트
		mapper.userChating(mag.getMag().replaceAll("\\r|\\n", ""));
		
		
		restTemplate = new RestTemplate();
		headers = new HttpHeaders();
		headers.setContentType(new MediaType("application", "json", StandardCharsets.UTF_8));
		headers.set("Authorization", "Bearer " + API_KEY);
		
		jsonObj.put("model","gpt-3.5-turbo");
		
		JSONArray jsonList = new JSONArray();
		for(LogInfo log : mapper.chatingLog()) {
			JSONObject massageObj = new JSONObject();
			massageObj.put("role",log.getMessageRole());
			massageObj.put("content",log.getMessageContent());
			jsonList.put(massageObj);
		}
				
		jsonObj.put("messages",jsonList);
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonObj.toString(), headers);
		
		ResponseEntity<ChatGpt> responseEntity = restTemplate.postForEntity(API_URL, requestEntity, ChatGpt.class);
		
		ChatGpt responseBytes = responseEntity.getBody();
		Choice choices = responseBytes.getChoices().get(0);
		Message message = choices.getMessage();
		String content = message.getContent().replaceAll("\\r|\\n", "");
		message.setContent(content);
		choices.setMessage(message);
		//이제 여기에서 sql에 인설트
		mapper.systemChating(choices);
		
		// 대화내용 찾아서 출력요청
		return mapper.chating(); 
	}
	
	public ArrayList<LogInfo> chating(){
		ArrayList<LogInfo> chat = null;
		if(mapper.count() != 0) {
			chat = mapper.chating();
		}
		return chat; 
	}
}
