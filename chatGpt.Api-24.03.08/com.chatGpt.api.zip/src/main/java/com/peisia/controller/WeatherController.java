package com.peisia.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.peisia.service.ChatGptService;
import com.peisia.spring.dto.SearchDto;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Controller
@RequestMapping("/chat/*")
public class WeatherController {

	@Setter(onMethod_ = @Autowired)
	private ChatGptService service;
	
	@PostMapping("/chating")
	public String chat(Model m) {
		m.addAttribute("chatGpt",service.chating());
		return"/chatGpt";
	}
	
	
	@GetMapping("/chating")
	public String chatGpt(SearchDto mag, Model m) {
		
		m.addAttribute("chatGpt",service.chating(mag));
		
		return "/chatGpt";
	}

	
}
