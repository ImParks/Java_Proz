package com.peisia.spring.dto;

import lombok.Data;

@Data
public class LogInfo {

	 private int number;
	 private int index;
	 private String messageRole;
	 private String messageContent;
	 private String finish_reason;
	 private String time;
}
