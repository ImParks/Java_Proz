
package com.peisia.spring.dto.chatGptDto;

import lombok.Data;

@Data
public class Message {

    private String role;
    private String content;

}
