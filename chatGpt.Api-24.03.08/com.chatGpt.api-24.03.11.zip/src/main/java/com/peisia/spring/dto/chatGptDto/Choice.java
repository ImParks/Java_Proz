
package com.peisia.spring.dto.chatGptDto;

import lombok.Data;

@Data
public class Choice {

    private int index;
    private Message message;
    private Object logprobs;
    private String finish_reason;

}
