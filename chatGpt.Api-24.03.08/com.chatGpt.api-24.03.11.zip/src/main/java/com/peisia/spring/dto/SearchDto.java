package com.peisia.spring.dto;

import java.util.ArrayList;

import lombok.Data;

@Data
public class SearchDto {
 private String mag="";
 private ArrayList<LogInfo>log;
}
