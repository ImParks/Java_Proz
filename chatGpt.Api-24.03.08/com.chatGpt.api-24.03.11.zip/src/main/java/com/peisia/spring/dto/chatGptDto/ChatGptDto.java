package com.peisia.spring.dto.chatGptDto;

public class ChatGptDto {

	public ChatGpt chatGpt;
	
}
