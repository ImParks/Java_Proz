package com.peisia.service;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.peisia.mapper.ChatGptMapper;
import com.peisia.service.util.Escape;
import com.peisia.spring.dto.LogInfo;
import com.peisia.spring.dto.SearchDto;
import com.peisia.spring.dto.chatGptDto.ChatGpt;
import com.peisia.spring.dto.chatGptDto.Choice;
import com.peisia.spring.dto.chatGptDto.Message;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class ChatGptServiceImpl implements ChatGptService{
	

	@Setter(onMethod_ = @Autowired)
	private ChatGptMapper mapper;
	@Setter(onMethod_ = @Autowired)
	private Escape escape;
	private final String API_KEY = "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";
	private final String API_URL = "https://api.openai.com/v1/chat/completions";
    private RestTemplate restTemplate;
    private HttpHeaders headers;
    JSONObject jsonObj = new JSONObject();
    
	public ArrayList<LogInfo> chating(SearchDto mag) {
		// 질문을 먼저 데이터베이스에 저장.
		mapper.userChating(mag.getMag());

		
		
		
		  // API 요청을 위한 RestTemplate 및 헤더 설정
		restTemplate = new RestTemplate();		
		headers = new HttpHeaders();
		
		
		// JSON 요청 데이터를 구성.
		headers.setContentType(new MediaType("application", "json", StandardCharsets.UTF_8));
		headers.set("Authorization", "Bearer " + API_KEY);
		jsonObj.put("model","gpt-3.5-turbo");
		
		// 데이터 베이스에서 시스템과의 대화 내용을 조회하고 Json 배열로 구성,
		JSONArray jsonList = new JSONArray();
		for(LogInfo log : mapper.chatingLog()) {
			JSONObject massageObj = new JSONObject();
			massageObj.put("role",log.getMessageRole());
			massageObj.put("content",log.getMessageContent());
			jsonList.put(massageObj);
		}
		jsonObj.put("messages",jsonList);
		
		// API 요청을 위한 HttpEntity를 생성하고 요청을 전송.
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonObj.toString(), headers);
		ResponseEntity<ChatGpt> responseEntity = restTemplate.postForEntity(API_URL, requestEntity, ChatGpt.class);
		ChatGpt responseBytes = responseEntity.getBody();
		
		// 응답받은 선택지를 추출하고 데이터베이스에 저장
		Choice choices = responseBytes.getChoices().get(0);
		mapper.systemChating(choices);
		
		// 대화내용 찾아서 반환
		return mapper.chating(); 
	}
	
	public ArrayList<LogInfo> chating(){
		ArrayList<LogInfo> chat = null;
		if(mapper.count() != 0) {
			chat = mapper.chating();
		}
		return chat; 
	}
}
