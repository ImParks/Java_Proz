package com.peisia.service;

import java.util.ArrayList;

import com.peisia.spring.dto.LogInfo;
import com.peisia.spring.dto.SearchDto;

public interface ChatGptService {
		
	
	public ArrayList<LogInfo> chating(SearchDto mag);
	public ArrayList<LogInfo> chating();
	
}
