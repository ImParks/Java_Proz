package DataBase;

import MapPackage.MapLoadObj;
import MapPackage.MapObj;

public class VillageDB {

	public static void mapLoad() {
		for (int x = 0; DataBase.dbExecuteQuery("SELECT COUNT(*) FROM Village") > x; x++) {
			int num = DataBase.dbExecuteQuery("SELECT* FROM Village ORDER BY V_no LIMIT 1 OFFSET " + x, "V_no", x);
			int id = DataBase.dbExecuteQuery("SELECT * FROM Village WHERE V_no = " + num, "V_X", 0);
			int pw = DataBase.dbExecuteQuery("SELECT * FROM Village WHERE V_no = " + num, "V_Y", 0);
			String name = DataBase.dbExecuteQuery("SELECT * FROM Village WHERE V_no = " + num, "V_name", "");
			MapObj log = new MapObj(id, pw, name);
			MapLoadObj.map.add(log);
		}

	}
}