package DataBase;

import CharacterPackage.LoadObj;
import FunctionPackage.So;

public class NpcDB {
	 // npc 리스트 출력
	public static boolean npcList(int a) {
		for (int x = 0; a > x; x++) {
			int myNpcnum = DataBase.dbExecuteQuery("SELECT* FROM Npc WHERE N_ID = '" + LoadObj.myNpcID + "' ORDER BY N_no LIMIT 1 OFFSET " + x +";", "N_no", x);
			So.lin();
			So.t("[번호:" + DataBase.dbExecuteQuery("SELECT * FROM Npc WHERE N_no = " + myNpcnum, "N_number", "") + "]");
			So.t("[닉네임:" + DataBase.dbExecuteQuery("SELECT * FROM Npc WHERE N_no = " + myNpcnum, "N_name", "") + "]");
			So.t("[레벨:" + DataBase.dbExecuteQuery("SELECT * FROM Npc WHERE N_no = " + myNpcnum, "N_level", 0) + "]");
			So.ln("[직업:" + DataBase.dbExecuteQuery("SELECT * FROM Npc WHERE N_no = " + myNpcnum, "N_job", "") + "]");
			So.lin();
		}
		return true;
	}
	 // npc 넘버 출력
	public static int myNpcNo(int a, int b) {
	int number = 0;
	for(int x = 0; a > x; x++ ) {
	int myNpcnum = DataBase.dbExecuteQuery("SELECT* FROM Npc WHERE N_ID = '" + LoadObj.myNpcID + "' ORDER BY N_no LIMIT 1 OFFSET " + x +";", "N_number", x);
	if (b == myNpcnum) {
		number = myNpcnum;
		}
	}

return number;
	}
	
	public static int myNpcGold(int a) {
		
		int gold = DataBase.dbExecuteQuery("SELECT* FROM Npc WHERE N_no = '" + LoadObj.myNpcNo + ";", "N_number", 0);
		return gold;
		
	}
	
	public static void save(String a) {
		String x = String.format("UPDATE NPC SET "+ a + " WHERE N_no = "+ LoadObj.myNpcNo + ";" );
		DataBase.dbExecuteUpdate(x);
	}
	
	public static int npcLoca(String a) {
		return DataBase.dbExecuteQuery("SELECT * FROM Npc WHERE N_no = '" + LoadObj.myNpcNo + "';",a,0);
	}
	
	public static void move(String a) {
		DataBase.dbExecuteUpdate("update Npc set "+ a +" WHERE N_no = "+ LoadObj.myNpcNo +";");
	}
	
}
