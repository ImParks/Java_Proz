package DataBase;

public class MonsterDB {

}
