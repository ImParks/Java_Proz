package RpgPackage;

public class Stop {

	public static void stop() {
		
		
		
	}
	
}
