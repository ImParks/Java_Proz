package RpgPackage;

import CharacterPackage.Stats;
import FunctionPackage.So;
import FunctionPackage.TextBox;
import MapPackage.MapLoadObj;
import MapPackage.Mini;

public class World {


	public static void world() {
		end:
		while (true) {
			So.ln("1: 이동, 2: 휴식,3:스텟창, 4: 아이템창, 5: 미니맵");
			TextBox.cmd = TextBox.r("입력");
			switch (TextBox.cmd) {
			case "1":
				Move.move();
				break;
			case "2":
				Stop.stop();
				break;
			case "3":
				Stats.stats();
				break;
			case "4":
//				Item.item();
				break;
			case "5":
				Mini.mini();
				break;

			case "0": // 로그아웃
				
				
				break end;

			default:
				So.ln("할수없는 행동입니다.");
				break;
			}
	
		}

	}
	
}
