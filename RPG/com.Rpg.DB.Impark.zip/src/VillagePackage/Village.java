package VillagePackage;

import DataBase.NpcDB;
import FunctionPackage.So;
import FunctionPackage.TextBox;

public class Village {

	public static void village() {
		// 마을도착 상호작용 
		back:
		while (true) {
			So.ln(" 1 : 상점(소모품 및 장비), 2 : 여관(체력회복), 3 : 대장간(수리중), 4 : 길드(전직가능인대 파산함), 0 : 떠나기");
			TextBox.cmd = TextBox.r("입력");
			switch (TextBox.cmd) {
			case "1":
				
				break;
			case "2":
				
				break;
			case "3":
				
				break;
			case "4":
				
				break;
				
			case "0":
				
				break back;
			default:
				So.ln("당신은 뒷골목으로 잘못들어가서 깡패한태 돈을 뜯겼습니다.");
				NpcDB.save("N_gold = N_gold - 300");
				break;
			}
			
		}
		
	}
	
}
