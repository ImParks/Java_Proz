package MapPackage;

import DataBase.NpcDB;
import FunctionPackage.So;

public class Mini {

	public static void mini() {

		int miny = -4; // 이거는 미니맵 크기 xCk, yCk
		int minx = 4;
		int x = NpcDB.npcLoca("N_x");
		int y = NpcDB.npcLoca("N_y");// 캐릭터 좌표값

		
		int xx;
		int yy;
		for (int yCk = 4; yCk >= miny; yCk--) {
			for (int xCk = -4; xCk <= minx; xCk++) {

				xx = x + xCk;
				yy = y + yCk;

				if (x == xx && y == yy) {
					So.t("나");
				} else {
					MapIcon.village(xx, yy, xCk);
				}

			}

		}

	}

}
