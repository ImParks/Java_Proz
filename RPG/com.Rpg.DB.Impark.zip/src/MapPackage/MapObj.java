package MapPackage;

import FunctionPackage.So;

public class MapObj {

	public int x;
	public int y;
	public String name;

	public MapObj(int x, int y, String name) {
		this.x = x;
		this.y = y;
		this.name = name;
	}

	public void info() {
		So.ln("마을에 도착하였습니다.");
	}

}
