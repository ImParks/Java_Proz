package MapPackage;

import DataBase.NpcDB;
import FunctionPackage.So;
import RpgPackage.Active;

public class Movement {

	public static void straight() {
		NpcDB.move("N_y = N_y+1");
		So.ln("캐릭터가 앞으로 이동하였습니다..");
		Active.active();

	}

	public static void junior() {
		NpcDB.move("N_y = N_y-1");
		So.ln("캐릭터가 뒤로 이동하였습니다.");
		Active.active();

	}

	public static void right() {
		NpcDB.move("N_x = N_x+1");
		So.ln("캐릭터가 왼쪽으로 이동하였습니다.");
		Active.active();

	}

	public static void left() {
		NpcDB.move("N_x = N_x-1");
		So.ln("캐릭터가 오른쪽으로 이동하였습니다..");
		Active.active();
	
	}
}
