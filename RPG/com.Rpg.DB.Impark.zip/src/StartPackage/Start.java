package StartPackage;

import FunctionPackage.So;
import FunctionPackage.TextBox;

public class Start {
	public static void start() {
		So.title("로그인||회원가입");
		end:
		while (true) {

			So.ln("1 : 로그인");
			So.ln("2 : 회원가입");
			So.ln("x : 시스템 종료");
			TextBox.cmd = TextBox.r();
			switch (TextBox.cmd) {
			case "1": // 로그인

				Login.login();

				break;
			case "2": // 회원가입

				Join.join();

				break;
				
			case "x": // 시스템 종료 
				
				break end;
			}
		}
	}
}
