package StartPackage;

import DataBase.DataBase;

public class Main {
	public static void main(String[] args) {
		DataBase.run();
		Start.start();
	}
}
