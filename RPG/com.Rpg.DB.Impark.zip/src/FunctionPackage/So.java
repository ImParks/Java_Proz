package FunctionPackage;

public class So {

	public static void t(String s) {
		System.out.print(s);
	}

	public static void ln(String s) {
		System.out.println(s);
	}

	public static void line() {
		System.out.println("================================================");
	}
	public static void lin() {
		System.out.println("------------------------------------------------");
	}


	public static void wn() { // 엔터 넣는함수
		System.out.println();
	}

	public static void homeText() {
		So.line();
		So.ln("1: 글 목록 || 2:글 읽기 || 3: 글쓰기 || 4: 글 수정/삭제 || x: 로그아웃");
		So.line();

	}

	public static void title(String t) {
		So.line();
		So.ln("================== " + t + " ========================");
		So.line();
	}
	
	public static void tit(String t) {
		So.line();
		So.ln("================== " + t + " ========================");
		So.line();
	}

	public static void textList(String cmd) {
		String list = "";
		list = cmd + list;

	}
}
