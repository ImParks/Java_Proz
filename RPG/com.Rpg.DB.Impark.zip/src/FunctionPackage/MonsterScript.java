package FunctionPackage;

public class MonsterScript {

}
