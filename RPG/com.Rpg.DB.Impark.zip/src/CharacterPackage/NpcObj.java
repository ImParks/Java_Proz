package CharacterPackage;

import FunctionPackage.So;

public class NpcObj {
	public static String idName;
	public static int idOtp;
	public String id;
	public String name;
	public String sex;
	public String job;
	public int hp;
	public int str;
	public int dex;
	public int inte;
	public int luk;
	public int maxExp;
	public int exp;
	public int level;
	public int stat = 0;
	public int number;
	public int maxHp;
	public int otp;
	public int x;
	public int y;
	public int gold;
	int no = 0;

	public NpcObj(String id, String name, Boolean sex, String job, int str, int dex, int inte, int luk, int maxExp) {
		no = no + 1;
		otp = no;
		this.number = 0;
		this.id = id;
		this.name = name;
		if (sex) {
			this.sex = "남자";
		} else {
			this.sex = "여자";
		}
		this.job = job; // 직업
		this.hp = str * 10; // 체력
		this.maxHp = str * 10; // 체력
		this.str = str; // 힘
		this.dex = dex; // 덱스
		this.inte = inte; // 인트
		this.luk = luk; // 럭
		this.maxExp = maxExp; // 경험치
		this.exp = 0; // 경험치
		this.gold = 0;
		this.level = 1;
		this.x = 0;
		this.y = 0;
	}

	public void NpcInfo() {
		So.title("상태창");
		So.ln("[ 닉네임:" + name + "]");
		So.ln("[ 성별:" + sex + "]");
		So.ln("[ 레벨:" + level + "]");
		So.ln("[ 경험치:" + exp +"/" + maxExp + "]");
		So.ln("[ 체력:" + hp + "/ " + maxHp + "]");
		So.ln("[GOLD :" + gold + "g]");
		So.tit("스텟");
		So.ln("[ STR :" + str + "]"); // 공격력, 체력 증가
		So.ln("[ DEX :" + dex + "]"); // 연속 공격확률, 회피 확률 증가
		So.ln("[ INT :" + inte + "]"); // 기습 확률 감소<- 내가 받는 피해가 크리티컬임, 반격 확률 감소<- 무조건 크리티컬임
		So.ln("[ LUK :" + luk + "]"); // 보상증가, 크리티컬 확률 증가
		So.ln("[ 잔여스텟 :" + stat + "]");
		So.line();
	}

	public void NpcList() {
		So.lin();
		So.t("[번호:" + number + "]");
		So.t("[닉네임:" + name + "]");
		So.t("[레벨:" + level + "]");
		So.ln("[직업:" + job + "]");
		So.lin();
	}
	
	public void npcBattlInfo(){
		So.tit("상태창");
		So.t("[닉네임:" + name +"]");
		So.t("[레벨:" + level +"]");
		So.t("[체력:" + hp +"/" + maxHp +"]");
		So.line();
	}
	
	public void levelUp(){
		if(this.exp >= this.maxExp) {
			this.exp = this.exp - this.maxExp;
			this.maxExp = this.maxExp *= 1.2 ;
			So.t(level + " => ");
			this.level = this.level + 1;
			So.ln(level + "");
			this.stat = this.stat + 3;
			So.ln("플레이어가 레벨업하였습니다");
			
		}
	}


	
	
}
