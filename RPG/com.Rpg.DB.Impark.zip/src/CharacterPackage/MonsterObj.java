package CharacterPackage;

import FunctionPackage.So;

public class MonsterObj {
	
	public String name;
	public int hp;
	public int maxHp;
	public int atk;
	public int gold;
	public int exp;
	
	MonsterObj(String name, int hp, int atk, int gold, int exp){
		this.name = name;
		this.hp = hp;
		this.maxHp = hp;
		this.atk = atk;
		this.gold = gold;
		this.exp = exp;
	}
	
	public void infoMonster(){
		So.title("몬스터");
		So.ln("[" + name + "]");
		So.ln("[" + hp +"/" + maxHp +"]");
		So.line();
	}
	public void monsterBattlInfo(){
		So.tit("몬스터");
		So.t("[" + name + "]");
		So.t("[" + hp +"/" + maxHp +"]");
		So.line();
	}
	
	
}
