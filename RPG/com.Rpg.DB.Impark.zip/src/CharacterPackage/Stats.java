package CharacterPackage;

import FunctionPackage.So;
import FunctionPackage.TextBox;

public class Stats {

	public static void stats() {
		end:
		while (true) {
			
			LoadObj.MyNpc.NpcInfo();
			if (LodeObj.LoadObj.stat > 0) {
				So.ln("잔여스텟이 있습니다.");
				So.line();
				So.ln("| 1 : STR | 2: DEX | 3:INT | 4: LUK |");
				So.line();
			}
			TextBox.cmd = TextBox.r("입력");

			if (LodeObj.LoadObj.stat > 0) {
	
				switch (TextBox.cmd) {
				case "1":
					LodeObj.LoadObj.str++;
					LodeObj.LoadObj.maxHp += 10;
					LodeObj.LoadObj.stat -= 1;
					
					
					break;
				case "2":
					LodeObj.LoadObj.dex++;
					LodeObj.LoadObj.stat -= 1;
					break;
				case "3":
					LodeObj.LoadObj.inte++;
					LodeObj.LoadObj.stat -= 1;
					break;
				case "4":
					LodeObj.LoadObj.luk++;
					LodeObj.LoadObj.stat -= 1;
					break;
				case "0":
					So.ln("스텟창을 닫습니다.");
					break end;

				default:
					So.ln("잘못된 입력입니다.");
					break;
				}

			} else {
					break end;

			}
		}

	}

}
