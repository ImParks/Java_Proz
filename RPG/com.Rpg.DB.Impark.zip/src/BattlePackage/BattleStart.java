package BattlePackage;

import CharacterPackage.LoadObj;
import FunctionPackage.Random;
import FunctionPackage.So;

public class BattleStart {

	public static void battleStart() {

//		LoadObj.monsterObj();
//		int a = Random.random();
//		if(a < 5) {
//			So.ln("몬스터가 기습함");
//			MonsterSurprise.monsterSurprise();
//			BattlePage.battle();
//		} else if(a < 40) {
//			So.ln("몬스터 있음");
//			BattlePage.battle();
//		} else if(a < 50) {
//			So.ln("몬스터가 있으나 눈치를 못챔");
//			NpcSurprise.surprise();
//			BattlePage.battle();
//		} else {
//			So.ln("몬스터 없음");
//		}
	}
	
}
