package BattlePackage;

import CharacterPackage.LoadObj;
import FunctionPackage.Random;
import FunctionPackage.So;

public class NpcAtk {

	public static void npcAtk(String sur) {
		int npcDps;
		if (Random.random() < 30 + LodeObj.LoadObj.luk * 0.1) {
			npcDps = LodeObj.LoadObj.str * 2;
		} else {
			npcDps = LodeObj.LoadObj.str;
		}

		int monsterDps = LoadObj.Mons.atk;
		// 플레이어가 공격 연속공격도 함
		LoadObj.Mons.hp = LoadObj.Mons.hp - npcDps;
		if (Random.random() > 5 + LodeObj.LoadObj.dex * 0.1) {
			So.ln("완벽하게 공격하여");
		} else if (Random.random() > 10 + LodeObj.LoadObj.dex * 0.1) {
			So.ln("완벽하게 공격하여");
		} else if (Random.random() > 30 + LodeObj.LoadObj.dex * 0.1) {
			So.ln("완벽하게 공격하여");
		} else {
			
		}
		
		
		LoadObj.Mons.hp = LoadObj.Mons.hp - npcDps;
		So.ln("플레이어가 몬스터를 " + sur + "공격하였습니다.");
		So.ln("몬스터는 [" + npcDps + "]의 피해를 받았습니다.");

		// 몬스터가반격
		if (Random.random() > 30) {
			LodeObj.LoadObj.hp = LodeObj.LoadObj.hp - monsterDps;
			So.ln("몬스터가 반격하였습니다.");
			So.ln("플레이어는 [" + monsterDps + "] 의 피해를 받았습니다.");

		}

	}

}

