package BattlePackage;

import CharacterPackage.LoadObj;
import FunctionPackage.So;

public class Lose {

	public static void lose() {
		int loseExp = LodeObj.LoadObj.maxExp / 5;
		
		// 전투에서 패배하였습니다.
		So.line();
		So.ln("전투에서 패배하였습니다.");
		So.lin();
		So.ln("전투에서 패배하여 [" + loseExp + "] 를 잃었습니다.");
		
		LodeObj.LoadObj.exp = LodeObj.LoadObj.exp - loseExp ;
		if(LodeObj.LoadObj.exp <= 0) {
		
			LodeObj.LoadObj.exp = 0;
			
		}
	}
	
}
