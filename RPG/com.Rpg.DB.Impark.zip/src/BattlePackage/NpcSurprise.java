package BattlePackage;


public class NpcSurprise {

	public static void surprise() {
		NpcAtk.npcAtk("기습");
		
	}
	
	
}
