package com.Jsp.Board;

public class Board {
	public static final int PAGE = 5;
	static public final int PAGE_LINK = 3;	
}
