package com.Jsp.Board.DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Dao extends Db {
	private static Connection con = null;
	private static Statement st = null;
	private static ResultSet rs = null;
	private static Dto post = null;
	private static ArrayList<Dto> posts = new ArrayList<>();
	private static String myName;
	private static String myNo;

	public static void login(String a, String b) {
		myName = a;
		myNo = b;
	}
	
	public static String name() {
		return myName;
	}

	public static void post(Dto a) {
		post = null;
		post = a;
	}

	public static void dao(String a, String b) {
		try {
			Class.forName(DB_LINK);
			con = DriverManager.getConnection(DB_URL, DB_ID, DB_PW);
			st = con.createStatement();
			if (a.equals("del")) {
				del(b);
			} else if (a.equals("write")) {
				write(b);
			} else if (a.equals("read")) {
				read(b);
			} else if (a.equals("list")) {
				list();
			} else if (a.equals("fix")) {
				fix(b);
			}

			st.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 삭제
	private static void del(String a) {
		String sql = String.format("DELETE FROM %s WHERE B_no = %s", DB_NAME, a);
		try {
			st.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// 쓰기
	private static void write(String a) {
		String sql = String.format(
				"INSERT INTO %s(B_time,B_title,B_text,B_name,B_num) VALUES (now(),'%s','%s','%s',%s)", DB_NAME,
				post.title, post.text, myName, myNo);
		try {
			st.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// 읽기
	private static void read(String a) {
		String sql = String.format("SELECT * FROM %s WHERE B_no = %s", DB_NAME, a);
		
		try {
			rs = st.executeQuery(sql);
			
			rs.next();

			post = new Dto(rs.getString("B_no"), rs.getString("B_title"), rs.getString("B_time"),
					rs.getString("B_name"), rs.getString("B_hit"), rs.getString("B_text"));
			sql = String.format("UPDATE %s SET B_hit = B_hit + 1 WHERE B_no = %s", DB_NAME, rs.getString("B_no"));
			st.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("오류");
		}

	}

	public Dto getRead(String a) {
		post = null;
		dao("read", a);
		return post;
	}

	// 리스트
	private static void list() {
		posts = new ArrayList<>();
		String sql = String.format("SELECT * FROM %s", DB_NAME);
		try {
			rs = st.executeQuery(sql);
			while (rs.next()) {
				posts.add(new Dto(rs.getString("B_no"), rs.getString("B_title"), rs.getString("B_time"),
						rs.getString("B_name"), rs.getString("B_hit")));
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	public ArrayList<Dto> getList() {
		post = null;
		dao("list", "");
		return posts;
	}

	// 수정
	private static void fix(String a) {
		String sql = String.format("UPDATE %s SET B_title = '%s' ,B_text = '%s' WHERE B_no = " + a, DB_NAME, post.title,
				post.text);
		try {
			st.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
