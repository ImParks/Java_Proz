package com.Jsp.Board.DB;

public class Dto {
	public String no;
	public String title;
	public String time;
	public String name;
	public String hit;
	public String text;
	
	
	Dto(String title,String text) {
		this.title = title;
		this.text = text;
	}
	Dto(String no, String title, String time, String name, String hit) {
		this.no = no;
		this.title = title;
		this.time = time;
		this.name = name;
		this.hit = hit;
	}

	Dto(String no, String title, String time, String name, String hit, String text) {
		this.no = no;
		this.title = title;
		this.time = time;
		this.name = name;
		this.hit = hit;
		this.text = text;

	}

}
