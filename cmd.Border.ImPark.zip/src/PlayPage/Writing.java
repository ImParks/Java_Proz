package PlayPage;

import ObjPage.BoardObj;
import ObjPage.Load;
import ObjPage.Post;
import ObjPage.So;
import ObjPage.TextBox;

public class Writing {

	public static void writing() {

		TextBox.title("글쓰기");

		String title = BoardObj.make("제목");

		String content = BoardObj.make("내용");

		So.ln("작성이 완료되었습니다.");

		Post p = new Post(title, content, Login.idName);

		Load.gather.add(p);

	}

}
