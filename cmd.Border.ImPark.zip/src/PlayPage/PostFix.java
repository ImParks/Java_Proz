package PlayPage;

import ObjPage.BoardObj;
import ObjPage.Load;
import ObjPage.Post;
import ObjPage.So;
import ObjPage.TextBox;

public class PostFix {

	public static void postFix() {

		TextBox.title("글수정하기");
		int cmd;

		while (true) {

			So.ln("수정하고싶은 글 번호를 작성해주세요");
			So.ln("뒤로가기 : 0");
			BoardObj.cmd = BoardObj.sc.next();
			if (BoardObj.cmd.equals("0")) {
				break;
			}

			while (true) {
				try {
					cmd = Integer.parseInt(BoardObj.cmd);
					break;
				} catch (NumberFormatException e) {
					System.out.println("올바른 숫자 형식이 아닙니다.");
					BoardObj.cmd = BoardObj.sc.next();
				}
			}

			for (Post p : Load.gather) {

				if (cmd == p.number) {
					p.title = BoardObj.make("제목");
					p.content = BoardObj.make("제목");
//					p.name = BoardObj.make("제목");

					So.ln("작성이 완료되었습니다.");

					break;
				} else{
					So.ln("입력하신 번호는 없는번호입니다. 다음에 다시 입력해주세요 삐~");
					break;
				}

			}

		}
	}
}
