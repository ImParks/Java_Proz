package PlayPage;

import ObjPage.BoardObj;
import ObjPage.Load;
import ObjPage.LoginObj;
import ObjPage.So;
import ObjPage.TextBox;

public class Join {

	public static void join() {

		TextBox.title("회원가입");

			String id; // 아이디 입력
			
			while(true) {
				boolean ck = false;
				id = BoardObj.makeJoin("ID");
				for (LoginObj chak : Load.log) {
					if (chak.id.equals(id)) {
						So.ln("중복된 아이디가 있습니다.");
						ck = true;
						break;
					}	
				}
				if (ck == false) {
					break;
				}
			}

			String pw;
			pw = BoardObj.makeJoin("PW");



			So.ln("작성이 완료되었습니다.");
			LoginObj p = new LoginObj(id, pw);
			Load.log.add(p);


	}

}
