package PlayPage;

import ObjPage.BoardObj;
import ObjPage.Load;
import ObjPage.LoginObj;
import ObjPage.So;
import ObjPage.TextBox;



public class Login {

	public static String idName;
	
	public static void login() {

		boolean idCheck = false;
		TextBox.title("로그인");
		So.ln("아이디를 입력해주세요");
		// 아이디를 입력해주세요,
		String id = BoardObj.rl("ID");
		// 비밀번호를 입력해주세요,
		String pw = BoardObj.rl("PW");
		// 입력한 아이디 비밀번호 조회
		for (LoginObj idCheckObj : Load.log) {
			if (idCheckObj.id.equals(id)) {
				idCheck = true;
				if (idCheckObj.pw.equals(pw)) {
					idName = id;
					Home.home();
				}else {
					So.ln("비밀번호를 잘못 입력했습니다.");
				}
			}
		}

		if (!idCheck) {
			So.ln("아이디를 잘못 입력했습니다.");
		}
	}
}
