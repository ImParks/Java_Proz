package ObjPage;

import java.util.ArrayList;

public class Load {

	
	public static ArrayList<Post> gather = new ArrayList<>();
	public static ArrayList<LoginObj> log = new ArrayList<>();

	
	
}
