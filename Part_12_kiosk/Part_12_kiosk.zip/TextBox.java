package Part_12_kiosk;

public class TextBox {
	
		
	
	
	
	

}
