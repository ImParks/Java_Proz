package Part_12_kiosk;

public class Main {

	public static void main(String[] args) {

		Kiosk disp = new Kiosk();
		
			disp.display();
			
		
			
	 

	}
}