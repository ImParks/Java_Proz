package Part_12_kiosk;

public class So {
	
	public static void t(String s) {
		System.out.print(s);
	}
	public static void ln(String s) {
		System.out.println(s);
	}
	
	public static void line() {
		System.out.println("============================================");
	}

}
