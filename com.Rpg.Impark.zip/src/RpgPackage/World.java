package RpgPackage;

import CharacterPackage.LodeObj;
import CharacterPackage.NpcObj;
import FunctionPackage.TextBox;

public class World {

	public static void world() {
		
		while (true) {
			TextBox.cmd = TextBox.r("입력");
			switch (TextBox.cmd) {
			case "w":
				
				break;
			case "a":
				
				break;
			case "s":
				
				break;
			case "d":
				
				break;
			case "0": // 로그아웃
				for(NpcObj ck : LodeObj.npc) {
					if(ck.otp == LodeObj.npcPick.get(1).otp) {
						ck.level = LodeObj.npcPick.get(1).level;
						ck.exp = LodeObj.npcPick.get(1).exp;
						ck.str = LodeObj.npcPick.get(1).str;
						ck.dex = LodeObj.npcPick.get(1).dex;
						ck.inte = LodeObj.npcPick.get(1).inte;
						ck.luk = LodeObj.npcPick.get(1).luk;

					}
				}
				break;

			default:
				break;
			}
			
			
			
		}
		// 지금 어디에있습니다.
		
		// 어디로 움직일까요
		
		// 움직일지 휴식할지
		
		// 움직이고나서 몬스터를 만나고
		
		// 몬스터랑 전투를 하고
		
		// 공격 방어
		
		// 몬스터랑 전투틑 할때
		
		// 전투하는 함수
		
		// 이기면 보상이 나오고
		
		// 레벨업 하면 스텟을 3개 올릴수있음
		
		// 전투에서 지면 경험치 잃음
		
		// 턴 게념도 만들어야함
	
		
	}
	
}
