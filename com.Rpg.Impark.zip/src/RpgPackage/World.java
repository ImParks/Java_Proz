package RpgPackage;

import CharacterPackage.LodeObj;
import CharacterPackage.NpcObj;
import CharacterPackage.Stats;
import FunctionPackage.So;
import FunctionPackage.TextBox;

public class World {


	public static void world() {
		end:
		while (true) {
			So.ln("1: 이동, 2: 휴식,3:스텟창, 4: 아이템창");
			TextBox.cmd = TextBox.r("입력");
			switch (TextBox.cmd) {
			case "1":
				Move.move();
				break;
			case "2":
				Stop.stop();
				break;
			case "3":
				Stats.stats();
				break;
			case "4":
//				Item.item();
				break;

			case "0": // 로그아웃
				for(NpcObj ck : LodeObj.npc) {
					if(ck.otp == LodeObj.MyNpc.otp) {
						ck = LodeObj.MyNpc;
					}
				}
				break end;

			default:
				So.ln("할수없는 행동입니다.");
				break;
			}
			
			
			
		}
		// 지금 어디에있습니다.
		
		// 어디로 움직일까요
		
		// 움직일지 휴식할지
		
		// 움직이고나서 몬스터를 만나고
		
		// 몬스터랑 전투를 하고
		
		// 공격 방어
		
		// 몬스터랑 전투틑 할때
		
		// 전투하는 함수
		
		// 이기면 보상이 나오고
		
		// 레벨업 하면 스텟을 3개 올릴수있음
		
		// 전투에서 지면 경험치 잃음
		
		// 턴 게념도 만들어야함
	
		
	}
	
}
