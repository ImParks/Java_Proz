package RpgPackage;

import FunctionPackage.So;
import FunctionPackage.TextBox;
import MapPackage.Movement;

public class Move {

	public static void move() {
		end:
		while (true) {
			So.ln("          W : 전진");
			So.ln(" A : 왼쪽, S : 후진, D : 오른쪽");
			TextBox.cmd = TextBox.rl("이동");
			switch(TextBox.cmd) {
			case "w" :
				Movement.straight();
				break end;
			case "a" :
				Movement.left();
				break end;
			case "s" :
				Movement.junior();
				break end;
			case "d" :
				Movement.right();
				break end;
			case "0" :
				
				break end;
			
			
			
			
			}
			
			
		}
		
	}
	
}
