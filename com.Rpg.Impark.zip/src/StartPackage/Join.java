package StartPackage;

import FunctionPackage.So;
import FunctionPackage.TextBox;
import LoginPackage.LoginLodeObj;
import LoginPackage.LoginObj;

public class Join {
	public static void join() {

		So.title("회원가입");

			String id; // 아이디 입력
			
			while(true) {
				boolean ck = false;
				id = TextBox.makeJoin("ID");
				for (LoginObj chak : LoginLodeObj.idList) {
					if (chak.id.equals(id)) {
						So.ln("중복된 아이디가 있습니다.");
						ck = true;
						break;
					}	
				}
				if (ck == false) {
					break;
				}
			}

			String pw;
			pw = TextBox.makeJoin("PW");



			So.ln("작성이 완료되었습니다.");
			LoginObj p = new LoginObj(id, pw);
			LoginLodeObj.idList.add(p);


	}
}
