package StartPackage;

import FunctionPackage.So;
import FunctionPackage.TextBox;
import LoginPackage.LoginLodeObj;
import LoginPackage.LoginObj;

public class Login {
	public static String idName;
	
	public static void login() {

		boolean idCheck = false;
		So.title("로그인");
		So.ln("아이디를 입력해주세요");
		// 아이디를 입력해주세요,
		String id = TextBox.r("ID");
		// 비밀번호를 입력해주세요,
		String pw = TextBox.r("PW");
		// 입력한 아이디 비밀번호 조회
		for (LoginObj idCheckObj : LoginLodeObj.idList) {
			if (idCheckObj.id.equals(id)) {
				idCheck = true;
				if (idCheckObj.pw.equals(pw)) {
					idName = id;
					Home.home();
				}else {
					So.ln("비밀번호를 잘못 입력했습니다.");
				}
			}
		}

		if (!idCheck) {
			So.ln("아이디를 잘못 입력했습니다.");
		}
	}
}
