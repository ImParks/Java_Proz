package StartPackage;

import FunctionPackage.So;
import FunctionPackage.TextBox;
import NpcPackage.NpcDel;
import NpcPackage.NpcList;
import NpcPackage.NpcRegen;

public class Home {

	public static void home() {
		
		// 1번 캐릭터 목록 2번 캐릭터 생성 3번 캐릭터 삭제
		end:
		while (true) {
			So.ln("1번 캐릭터 목록 2번 캐릭터 생성 3번 캐릭터 삭제 0번 로그아웃");
			TextBox.cmd = TextBox.r("입력");
			switch (TextBox.cmd) {

			// 캐릭터 목록
			case "1":
				
				NpcList.npcList();
				
			break;
			// 캐릭터 생성
			case "2":
			
				NpcRegen.npcRegen();
				
			break;
			// 캐릭터 삭제
			case "3":
				
				NpcDel.npcDel();
				
			break;
			
			case "0":
				

				break end;
			
			// 예외 입력
			default:
				break;
			}
		}

	}

}
