package battlePackage;

public class Battle {

}
