package FunctionPackage;

public class NpcScript {

}
