package FunctionPackage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;



public class TextBox {
	public static Scanner sc = new Scanner(System.in);
	public static BufferedReader re = new BufferedReader(new InputStreamReader(System.in));
	public static String cmd;
	
	public static String r() {
		return sc.next();
	}
	
	public static String r(String a) {
		So.ln(a + ":");
		return sc.next();
	}
	
	public static String rl(String comment) {
		So.t(comment + ":");

		try {
			return re.readLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public static String makeJoin(String textBox) {
		String making;
		while (true) {
			making = TextBox.r(textBox);
			if(making.contains(" ")) {
				So.ln("공백은 유효하지않습니다.");
			} else if (making.length() > 0) {
				return making;
			} else {
				So.ln("잘못된 입력입니다.");
			}
		}
	}
}
