package FunctionPackage;

public class Random {

	static int a;
	
	public static int random() {
		a = (int)(Math.random()*101);
		return a;
	}
	
}
