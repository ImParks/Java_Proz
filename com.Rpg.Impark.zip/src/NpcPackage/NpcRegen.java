package NpcPackage;

import CharacterPackage.LodeObj;
import CharacterPackage.NpcObj;
import FunctionPackage.So;
import FunctionPackage.TextBox;
import StartPackage.Login;

public class NpcRegen {

	public static void npcRegen() {
		end: while (true) {
			Boolean sex;
			String job;
			int str = 5;
			int dex = 5;
			int inte = 5;
			int luk = 5;

			// 직업선택

			while (true) {
				job: while (true) {
					So.ln("1번 : 전사, 2번 : 사냥꾼, 3번 : 전술가, 4번 : 도적");
					TextBox.cmd = TextBox.r("입력");
					if (TextBox.cmd == "0") {
						return;
					}
					switch (TextBox.cmd) {
					case "1": // 전사
						job = "전사"; // 총합 25
						str = 10;
						dex = 7;
						break job;
					case "2": // 사냥꾼
						job = "사냥꾼";
						str = 7;
						dex = 10;
						break job;
					case "3": //
						job = "전술가";
						dex = 7;
						inte = 10;
						break job;
					case "4": //
						job = "도적";
						dex = 7;
						luk = 10;
						break job;
					default:
						So.ln("올바르지 않은 입력입니다.");
						break;
					}

				}

				// 성별선택
				sex: while (true) {
					So.ln("1번 : 남자, 2번 : 여자");
					TextBox.cmd = TextBox.r("입력");
					if (TextBox.cmd == "0") {
						return;
					}
					switch (TextBox.cmd) {
					case "1": //
						sex = true;
						break sex;
					case "2": //
						sex = false;
						break sex;

					default:
						So.ln("올바르지 않은 입력입니다.");
						break;
					}
				}
				// 캐릭터 이름 입력
				//
				So.ln("닉네임을 작성해주세요");
				String name = TextBox.makeJoin("입력");

				// 캐릭터 생성 완료
				So.ln("캐릭터 생성이 완료되었습니다.");
				NpcObj npc = new NpcObj(Login.idName, name, sex, job, str, dex, inte, luk);
				LodeObj.npc.add(npc);
				break end;
			}

		}

	}
}
