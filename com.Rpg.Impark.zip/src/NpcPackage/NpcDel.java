package NpcPackage;

import CharacterPackage.LodeObj;
import CharacterPackage.NpcObj;
import FunctionPackage.So;
import FunctionPackage.TextBox;
import RpgPackage.World;

public class NpcDel {

	public static void npcDel() {
		boolean npcCk = false;
		int cmd;
		NpcIdList.npcIdList();
		if (LodeObj.npc.size() > 0) {
			end: while (true) {
				So.ln("0 : 뒤로가기");
				TextBox.cmd = TextBox.rl("선택");
				if (TextBox.cmd.equals("0")) {
					break;
				}

				cmd = Integer.parseInt(TextBox.cmd);
				for (NpcObj pic : LodeObj.npcId) {
					if (cmd == pic.number) {
						npcCk = true;
						pic.NpcInfo();
						So.ln("정말로 캐릭터를 삭제하겠습니까?");
						break end;
					}
				}
			}
		}

		if (npcCk) {
			World.world();
		} else {
			So.ln("캐릭터 없음");
		}
	}

}
