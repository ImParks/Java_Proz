package NpcPackage;

import CharacterPackage.LodeObj;
import CharacterPackage.NpcObj;
import FunctionPackage.So;
import FunctionPackage.TextBox;
import RpgPackage.World;

public class NpcDel {

	public static void npcDel() {
		boolean npcCk = false;
		int cmd;
		NpcIdList.npcIdList();
		if (LodeObj.npc.size() > 0) {
			end: while (true) {
				So.ln("0 : 뒤로가기");
				while (true) {
					try {
						cmd = Integer.parseInt(TextBox.rl("입력"));
						break;
					} catch (NumberFormatException e) {
						So.ln("올바른 입력이 아닙니다. 다시 입력해주세요.");
					}
				}

				if (TextBox.cmd.equals("0")) {
					break;
				}

				for (NpcObj pic : LodeObj.npcId) {
					if (cmd == pic.number) {
						npcCk = true;
						pic.NpcInfo();
						So.ln("정말로 캐릭터를 삭제하겠습니까?");
						So.ln("1 : YES || 2 : NO");
						TextBox.cmd = TextBox.rl("선택");
						switch (TextBox.cmd) {
						case "1":
							So.ln("캐릭터를 삭제합니다.");
							LodeObj.npc.remove(pic);
							break end;
						case "2":
							So.ln("캐릭터 삭제를 취소합니다.");
							return;
						default:
							So.ln("올바르지 않은 입력입니다. 캐릭터 삭제를 종료합니다.");
							return;
						}

					}
				}
			}
		}

		if (npcCk) {
			
		} else {
			So.ln("캐릭터 없음");
		}
	}

}
