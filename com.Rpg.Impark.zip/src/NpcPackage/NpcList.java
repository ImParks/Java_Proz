package NpcPackage;

import CharacterPackage.LodeObj;
import CharacterPackage.NpcObj;
import FunctionPackage.So;
import FunctionPackage.TextBox;
import RpgPackage.World;
import StartPackage.Login;

public class NpcList {

	public static void npcList() {
		int no = 0;
		int cmd;
		// 내 아이디로 만든 캐릭터 확인
		if (LodeObj.npc.size() > 0) {

			for (NpcObj ck : LodeObj.npc) {
				if (ck.id.equals(Login.idName)) {
					no++;
					ck.number = no;
					LodeObj.lodeObj();
					LodeObj.npcId.add(ck);
					ck.NpcList();
				}
			}
			if (LodeObj.npcId.size() > 0) {

				while (true) {

					TextBox.cmd = TextBox.rl("선택");
					if (TextBox.cmd.equals("0")) {
						break;
					}
					cmd = Integer.parseInt(TextBox.cmd);
					for (NpcObj pic : LodeObj.npcId) {
						if (cmd == pic.number) {
							pic.NpcInfo();
							LodeObj.npcPick.add(pic);
							World.world();
						}
					}
				}
			} else {
				So.ln("캐릭터 없음");

			}
		} else {
			So.ln("캐릭터 없음");

		}
	}
}