package NpcPackage;

import CharacterPackage.LodeObj;
import CharacterPackage.NpcObj;
import FunctionPackage.So;
import FunctionPackage.TextBox;
import RpgPackage.World;

public class NpcList {

	public static void npcList() {

		int cmd;
		boolean npcCk = false;
		// 내 아이디로 만든 캐릭터 확인
		if (LodeObj.npc.size() > 0) {
			NpcIdList.npcIdList();

			if (LodeObj.npcId.size() > 0) {

				end: while (true) {
					So.ln("0 : 뒤로가기");
					TextBox.cmd = TextBox.rl("선택");
					if (TextBox.cmd.equals("0")) {
						break;
					}
					cmd = Integer.parseInt(TextBox.cmd);

					for (NpcObj pic : LodeObj.npcId) {
						if (cmd == pic.number) {
							npcCk = true;
							pic.NpcInfo();
							LodeObj.MyNpc = pic;
							break end;
						}
					}
				}
			}
		}
		if (npcCk) {
			World.world();
		} else {
			So.ln("캐릭터 없음");
		}

	}
}