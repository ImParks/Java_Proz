package NpcPackage;

import CharacterPackage.LodeObj;
import CharacterPackage.NpcObj;

public class NpcIdList {
	public static void npcIdList() {

		LodeObj.npcId.clear();

		int no = 0;


			for (NpcObj ck : LodeObj.npc) {
				if (ck.id.equals(NpcObj.idName)) {
					no++;
					ck.number = no;
					LodeObj.npcId.add(ck);
					ck.NpcList();


			}
		}
	}
}
