package LoginPackage;

import java.util.ArrayList;
import java.util.HashMap;

import CharacterPackage.LodeObj;

public class LoginLodeObj {
 
	public static ArrayList<LoginObj> idList = new ArrayList<>();
	public static HashMap<ArrayList<LoginLodeObj>,ArrayList<LodeObj>>idListz = new HashMap<>();
	// 아이디 -> 캐릭터를 땡겨오는걸 하고싶은대
   //
	
	//아이디를 만들고
	
	// 그 아이디에 캐릭터배열을 추가
	
	
	
}
