package LoginPackage;

import java.util.ArrayList;

public class LoginLodeObj {
 
	public static ArrayList<LoginObj> idList = new ArrayList<>();
	
}
