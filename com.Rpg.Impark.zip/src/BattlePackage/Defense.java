package BattlePackage;

import FunctionPackage.Random;
import FunctionPackage.So;

public class Defense {

	public static void defense() {
		
		if(Random.random() <= 70) {
			
			So.ln("플레이어가 방어에 성공하였습니다,");
				
		} else {
			So.ln("플레이어가 방어 시도를 하였으나 실패하였습니다.");
			MonsterAtk.monsterAtk("");
		}
		
	}
	
}
