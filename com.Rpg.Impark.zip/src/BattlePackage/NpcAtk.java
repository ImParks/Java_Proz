package BattlePackage;

import CharacterPackage.LodeObj;
import FunctionPackage.Random;
import FunctionPackage.So;

public class NpcAtk {

	public static void npcAtk(String sur) {

		int npcDps = LodeObj.MyNpc.str;
		int monsterDps = LodeObj.Mons.atk;
		// 플레이어가 공격
		LodeObj.Mons.hp = LodeObj.Mons.hp - npcDps;
		So.ln("플레이어가 몬스터를 "+ sur + "공격하였습니다.");
		So.ln("몬스터는 [" + npcDps + "]의 피해를 받았습니다.");

		// 몬스터가반격
		if (Random.random() > 30) {
			LodeObj.MyNpc.hp = LodeObj.MyNpc.hp - monsterDps;
			So.ln("몬스터가 반격하였습니다.");
			So.ln("플레이어는 [" + monsterDps + "] 의 피해를 받았습니다.");

		}

	}

}
