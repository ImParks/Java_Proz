package BattlePackage;

import CharacterPackage.LodeObj;
import FunctionPackage.So;

public class Lose {

	public static void lose() {
		int loseExp = LodeObj.MyNpc.maxExp / 5;
		
		// 전투에서 패배하였습니다.
		So.line();
		So.ln("전투에서 패배하였습니다.");
		So.lin();
		So.ln("전투에서 패배하여 [" + loseExp + "] 를 잃었습니다.");
		
		LodeObj.MyNpc.exp = LodeObj.MyNpc.exp - loseExp;
		if(LodeObj.MyNpc.exp <= 0) {
		
			LodeObj.MyNpc.exp = 0;
			
		}
		
	}
	
}
