package BattlePackage;


public class MonsterSurprise {

	public static void monsterSurprise() {
		MonsterAtk.monsterAtk("기습");
	}
	
}
