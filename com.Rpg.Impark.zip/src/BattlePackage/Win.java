package BattlePackage;

import CharacterPackage.LodeObj;
import FunctionPackage.So;

public class Win {

	public static void win() {
		
		int dropGold = LodeObj.Mons.gold;
		int dropExp = LodeObj.Mons.exp;
		// 전투에서 승리하였습니다.
		So.line();
		So.ln("전투에서 승리하였습니다.");
		So.lin();
		So.ln("전투에서 승리하여[" + dropGold + "g] [" + dropExp + "Exp ] 를 얻었습니다.");
		LodeObj.MyNpc.exp = LodeObj.MyNpc.exp + dropExp;
		LodeObj.MyNpc.levelUp();

		
		// 보상
		
	}
	
}
