package BattlePackage;

import CharacterPackage.LodeObj;

public class Attack {

	public static void attack() {

		// 플레이어가 공격
		NpcAtk.npcAtk("");
		// 몬스터가 공격
		if (LodeObj.Mons.hp > 0) {
			MonsterAtk.monsterAtk("");
		}

	}

}
