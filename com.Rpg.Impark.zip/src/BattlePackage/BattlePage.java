package BattlePackage;

import CharacterPackage.LodeObj;
import FunctionPackage.So;
import FunctionPackage.TextBox;

public class BattlePage {
	public static void battle() {
		end: while (true) {
			So.ln("1번:공격 , 2번: 방어");
			TextBox.cmd = TextBox.r("입력");
			switch (TextBox.cmd) {
			case "1": // 공격
				So.ln("플레이어가 공격을 하였습니다.");
				Attack.attack();
				break;
			case "2": // 방어
				So.ln("플레이어가 방어를 하였습니다.");
				Defense.defense();
				break;

			default:
				So.ln("올바르지않은 입력입니다.");
				break;
			}

			if (LodeObj.MyNpc.hp <= 0 || LodeObj.Mons.hp <= 0) { // 체력 0이 될때 결투 종료
				if (LodeObj.MyNpc.hp <= 0) {
					
					break end;
				}
				if (LodeObj.Mons.hp <= 0) {
					Win.win();
					break end;
				}
			}

		}
	}
}
