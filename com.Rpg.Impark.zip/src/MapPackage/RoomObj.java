package MapPackage;

import java.util.ArrayList;
import java.util.HashMap;

import CharacterPackage.NpcObj;

public class RoomObj {

	public static HashMap<NpcObj,MapObj> map = new HashMap<>(); // 캐릭터 현재 위치
	public static ArrayList<MapObj> allMap = new ArrayList<>(); // 캐릭터 현재 위치
		

	
}
