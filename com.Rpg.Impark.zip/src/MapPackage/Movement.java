package MapPackage;

import BattlePackage.BattleStart;
import CharacterPackage.LodeObj;
import FunctionPackage.So;

public class Movement {
	
	public static void straight() {

		LodeObj.MyNpc.y = LodeObj.MyNpc.y + 1;
		So.ln("캐릭터가 앞으로 이동하였습니다..");
		So.ln("캐릭터의 현제 위치는" + LodeObj.MyNpc.x + "/" + LodeObj.MyNpc.y + "입니다");
		BattleStart.battleStart();

	}

	public static void junior() {
		if (LodeObj.MyNpc.y > 1) {
			LodeObj.MyNpc.y = LodeObj.MyNpc.y - 1;
			So.ln("캐릭터가 뒤로 이동하였습니다.");
			So.ln("캐릭터의 현제 위치는" + LodeObj.MyNpc.x + "/" + LodeObj.MyNpc.y + "입니다");
			BattleStart.battleStart();
		} else {
			So.ln("이동할수 있는 공간이 없습니다.");
		}
	}

	public static void left() {
		if (LodeObj.MyNpc.x > 1) {
			LodeObj.MyNpc.x = LodeObj.MyNpc.x - 1;
			So.ln("캐릭터가 왼쪽으로 이동하였습니다.");
			So.ln("캐릭터의 현제 위치는" + LodeObj.MyNpc.x + "/" + LodeObj.MyNpc.y + "입니다");
			BattleStart.battleStart();
		} else {
			So.ln("이동할수 있는 공간이 없습니다.");
		}
	}

	public static void right() {

		LodeObj.MyNpc.x = LodeObj.MyNpc.x + 1;
		So.ln("캐릭터가 오른쪽으로 이동하였습니다..");
		So.ln("캐릭터의 현제 위치는" + LodeObj.MyNpc.x + "/" + LodeObj.MyNpc.y + "입니다");
		BattleStart.battleStart();

	}
}
