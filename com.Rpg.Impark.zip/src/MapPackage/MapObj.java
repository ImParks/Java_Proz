package MapPackage;

public class MapObj {
	
	public int x;
	public int y;
	int otp;
	MapObj(int otp){
		this.otp = otp;
		this.x = 1;
		this.y = 1;
	}


	
	
	
}
