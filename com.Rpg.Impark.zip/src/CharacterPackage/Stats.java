package CharacterPackage;

import FunctionPackage.So;
import FunctionPackage.TextBox;

public class Stats {

	public static void stats() {
		end:
		while (true) {
			
			LodeObj.MyNpc.NpcInfo();
			if (LodeObj.MyNpc.stat > 0) {
				So.ln("잔여스텟이 있습니다.");
				So.line();
				So.ln("| 1 : STR | 2: DEX | 3:INT | 4: LUK |");
				So.line();
			}
			TextBox.cmd = TextBox.r("입력");

			if (LodeObj.MyNpc.stat > 0) {
	
				switch (TextBox.cmd) {
				case "1":
					LodeObj.MyNpc.str++;
					LodeObj.MyNpc.maxHp += 10;
					LodeObj.MyNpc.stat -= 1;
					break;
				case "2":
					LodeObj.MyNpc.dex++;
					LodeObj.MyNpc.stat -= 1;
					break;
				case "3":
					LodeObj.MyNpc.inte++;
					LodeObj.MyNpc.stat -= 1;
					break;
				case "4":
					LodeObj.MyNpc.luk++;
					LodeObj.MyNpc.stat -= 1;
					break;
				case "0":
					So.ln("스텟창을 닫습니다.");
					break end;

				default:
					So.ln("잘못된 입력입니다.");
					break;
				}

			} else {
					break end;

			}
		}

	}

}
