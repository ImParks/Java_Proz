package CharacterPackage;

import java.util.ArrayList;

public class LodeObj {
	public static ArrayList<MonsterObj> monster = new ArrayList<>();
	public static ArrayList<NpcObj> npc = new ArrayList<>(); // 모든 아이디에 있는 캐릭터를 저장해놓고
	public static ArrayList<NpcObj> npcId = new ArrayList<>(); // 위에꺼를 아이디 곂치는것만해서 걸러서 만드는걸루다가	
	public static NpcObj MyNpc; //<- 객채
	public static MonsterObj Mons;
	
	
	public static void lodeObj() {
		npcId = new ArrayList<>();
	}
	
	public static void monsterObj() {
		Mons = new MonsterObj("오크",10,1,50,100);
	}
}