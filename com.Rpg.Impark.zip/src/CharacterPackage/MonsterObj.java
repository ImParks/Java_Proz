package CharacterPackage;

import FunctionPackage.So;

public class MonsterObj {
	
	String name;
	int hp;
	int maxHp;
	int atk;
	
	MonsterObj(String name, int hp, int atk){
		this.name = name;
		this.hp = hp;
		this.maxHp = hp;
		this.atk = atk;
	}
	
	public void infoMonster(){
		So.title("몬스터");
		So.ln("[" + name + "]");
		So.ln("[" + hp +"/" + maxHp +"]");
		So.line();
	}
	
	
}
