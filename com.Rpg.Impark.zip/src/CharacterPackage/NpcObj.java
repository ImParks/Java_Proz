package CharacterPackage;

import FunctionPackage.So;

public class NpcObj {

	public String id;
	public String name;
	public String sex;
	public String job;
	public int hp;
	public int str;
	public int dex;
	public int inte;
	public int luk;
	public int exp;
	public int level;
	public int stat = 0;
	public int number;
	public int maxHp;
	public int otp;
	int no = 0;
	
	public NpcObj(String id,String name,Boolean sex, String job,int str, int dex, int inte, int luk){
		no = no+1;
		otp = no;
		this.number = 0;
		this.id = id;
		this.name = name;
		if(sex) {
			this.sex = "남자";
		} else {
			this.sex = "여자";
		}
		this.job = job; // 직업
		this.hp = str * 10; // 체력
		this.maxHp = str * 10; // 체력
		this.str = str; // 힘
		this.dex = dex; // 덱스
		this.inte = inte; // 인트
		this.luk = luk; // 럭
		this.exp = 0; // 경험치
		this.level = 1;
	}
	
	public void NpcInfo(){
		So.title("상태창");
		So.ln("[ 닉네임:" + name + "]");
		So.ln("[ 성별:" + sex + "]");
		So.ln("[ 레벨:" + level + "]");
		So.ln("[ 체력:" + hp + "/ " + maxHp +"]");
		So.tit("스텟");
		So.ln("[ STR :" + str + "]"); // 공격력, 체력 증가
		So.ln("[ DEX :" + dex + "]"); // 연속 공격확률, 회피 확률 증가 
		So.ln("[ INT :" + inte + "]"); // 기습 확률 감소,반격 확률 감소
		So.ln("[ LUK :" + luk + "]"); // 보상증가, 크리티컬 확률 증가
		So.ln("[ 잔여스텟 :" + stat + "]"); // 보상증가, 크리티컬 확률 증가
		So.line();
		
	}
	public void NpcList(){
		So.lin();
		So.t("[번호:" + number + "]");
		So.t("[닉네임:" + name + "]");
		So.t("[레벨:" + level + "]");
		So.ln("[직업:" + job + "]");
		So.lin();
		
	}
	
}
