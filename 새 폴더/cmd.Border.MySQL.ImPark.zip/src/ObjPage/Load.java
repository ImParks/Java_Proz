package ObjPage;

import java.util.ArrayList;

public class Load {

	
	public static ArrayList<Post> gather = new ArrayList<>();
	public static ArrayList<LoginObj> log = new ArrayList<>(); // 아이디, 비밀번호 저장되는 함수

	
	
}
