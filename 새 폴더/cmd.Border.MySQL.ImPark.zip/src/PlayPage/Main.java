package PlayPage;

import DBPackage.Db;

public class Main {

	public static void main(String[] args) {
		Db.run();
		Start.start();
		Db.update();

	}
}
