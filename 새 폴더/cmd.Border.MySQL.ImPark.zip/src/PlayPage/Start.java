package PlayPage;

import ObjPage.BoardObj;
import ObjPage.So;
import ObjPage.TextBox;



public class Start {
	public static void start() {
		TextBox.title("로그인||회원가입");
		end:
		while (true) {

			So.ln("1 : 로그인");
			So.ln("2 : 회원가입");
			So.ln("x : 시스템 종료");
			BoardObj.cmd = BoardObj.sc.next();
			switch (BoardObj.cmd) {
			case "1": // 로그인

				Login.login();

				break;
			case "2": // 회원가입

				Join.join();

				break;
				
			case "3": //비회원
				Login.idName = "비회원";
				Home.home();
				
				
			case "x": // 시스템 종료 
				
				break end;
			}
		}
	}
}
