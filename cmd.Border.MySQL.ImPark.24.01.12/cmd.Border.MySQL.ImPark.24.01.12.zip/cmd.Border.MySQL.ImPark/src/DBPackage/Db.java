package DBPackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import ObjPage.Load;
import ObjPage.LoginObj;
import ObjPage.Post;
import PlayPage.Login;



public class Db {
	public static Connection con = null;
	public static Statement st = null;
	public static ResultSet result = null;
 // 시작시 작동, 어레이 리스트에 값을 넣는거
	public static void run() {

		dbInit("board");
		for (int x = 0	; dbExecuteQuery("SELECT COUNT(*) FROM board") > x; x++) {
			int num = dbExecuteQuery("SELECT* FROM board ORDER BY B_no LIMIT 1 OFFSET " + x, "B_no",x);
			int no = dbExecuteQuery("SELECT * FROM board WHERE B_no = " + num, "B_no",0);
			String title = dbExecuteQuery("SELECT * FROM board WHERE B_no = " + num, "B_title","");
			String time = dbExecuteQuery("SELECT * FROM board WHERE B_no = " + num, "B_time","");
			String content = dbExecuteQuery("SELECT * FROM board WHERE B_no = " + num, "B_text","");
			String name = dbExecuteQuery("SELECT * FROM board WHERE B_no = " + num, "B_id","");
			int hit = dbExecuteQuery("SELECT * FROM board WHERE B_no = " + num ,"B_hit",0);
			Post p = new Post(no, time, title, content, name, hit);
			Load.gather.add(p);
		}

		for(int x = 0; dbExecuteQuery("SELECT COUNT(*) FROM Login") > x; x++) {
			int num = dbExecuteQuery("SELECT* FROM Login ORDER BY L_no LIMIT 1 OFFSET " + x, "L_no",x);
			String id = dbExecuteQuery("SELECT * FROM Login WHERE L_no = " + num, "L_ID","");
			String pw = dbExecuteQuery("SELECT * FROM Login WHERE L_no = " + num, "L_PW","");
			LoginObj log = new LoginObj(id,pw);
			Load.log.add(log);
		}
		
	}

// 	아이디 비밀번호 생성
	public static void join(String id, String pw) {
		
		String x = String.format("INSERT INTO login(L_ID,L_PW) VALUE ('" + id + "','"+ pw + "');");
		LoginObj p = new LoginObj(id, pw);
		Load.log.add(p);
		dbExecuteUpdate(x);
		
		
	}
	
	
	
	
	
	
	
	
	

	//		Db.writing(title, title, content);
	// 글쓰기 하고 db에 저장, 시간 불러오기
	public static void writing(String title, String content) {

		String x = String.format("INSERT INTO board(B_title,B_time, B_hit, B_id, B_text) VALUE (' " + title
				+ "  ',now(),0,' " + Login.idName + " ',' " + content + " ');");
		dbExecuteUpdate(x);
		Post p = new Post(title, content, Login.idName , dbExecuteQuery("SELECT curtime() FROM DUAL", "curtime()", "1"));
		Load.gather.add(p);
	}
 // 글 번호 불러오기 
	public static int numb() {
		int a = dbExecuteQuery("SELECT MAX(B_no) FROM board", 1);

		return a;
	}
// 업데이트 함수, 프로그렘 종료시 실행
	public static void update() {
		for (Post q : Load.gather) {
			String x = String.format("update board set b_title = '" + q.title + "', B_hit = " + q.hit + ", b_text = '"
					+ q.content + "' WHERE B_no = " + q.number);
			dbExecuteUpdate(x);
		}
	}
// 파일 삭제함수
	public static void del(int a) {
		String x = String.format("DELETE FROM board WHERE B_NO = " + a);
		dbExecuteUpdate(x);
	}

	// 기본 연결 시작시 하는게 좋음
	private static void dbInit(String a) {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + a, "root", "root");
			st = con.createStatement(); // Statement는 정적 SQL문을 실행하고 결과를 반환받기 위한 객체다. Statement하나당 한개의 ResultSet 객체만을 열
										// 수있다.
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}

	// 결과 출력하는 함수
	private static String dbExecuteQuery(String query, String a, String q) {
		String text = q;
		try {
			result = st.executeQuery(query);
			while (result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				text = result.getString(a); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				return text;
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
		return text;
	}

	// 숫자 출력하는 함수
	private static int dbExecuteQuery(String query, String a, int q) {

		try {
			result = st.executeQuery(query);
			while (result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				int max = result.getInt(a); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				return max;
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
		return q;
	}

	// 카운트 하는 함수
	private static int dbExecuteQuery(String query, int a) {

		try {
			result = st.executeQuery(query);
			while (result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				int max = result.getInt(a); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				return max;
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
		return a;
	}

	// 카운트 반환
	private static int dbExecuteQuery(String query) {
		int max = 0;
		try {
			result = st.executeQuery(query);
			while (result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				max = result.getInt(1); // p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				return max;
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
		return max;
	}

	// 데이터 저장하는 함수
	private static void dbExecuteUpdate(String query) {
		try {
			st.executeUpdate(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}