package ObjPage;

public class LoginObj {

	public String id;
	public String pw;
	
	
	public LoginObj(String id,String pw){
		
		this.id = id;
		this.pw = pw;

		
	}
	
	
}
