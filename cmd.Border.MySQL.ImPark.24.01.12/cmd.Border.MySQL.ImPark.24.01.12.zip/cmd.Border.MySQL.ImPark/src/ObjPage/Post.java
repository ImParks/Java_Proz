package ObjPage;

import DBPackage.Db;

public class Post {
	
	public int no = 0;
	public int number;
	public String title;
	public String content;
	public String name;
	String time;
	public int hit;
	
	
	public Post(String title,String content,String name,String time){
		no = Db.numb();
		number = no;
		this.time = time;
		this.title = title; 
		this.content = content;
		this.name = name;
		this.hit = 0;
		
	}
	
	public Post(int no,String time, String title,String content, String name, int hit) {
	this.number = no;
	this.time = time;
	this.title = title;
	this.content = content;
	this.name = name;
	this.hit = hit;
	}
	
	public void  infoList() {
	So.ln("글 번호 [ " + number + " ]");
	So.t("제목 : " + title + "||");
	So.t("작성자 : " + name + "||");
	So.t("작성일 : " + time);
	So.ln("[조회수: "+hit+"]"  );
	So.line();
		
		
	}
	
	public void  infoPost() {
		this.hit = this.hit + 1;
		So.ln("글 번호 [ " + number + " ]");
		So.ln("제목 : " + title);
		So.ln("작성자 : " + name);
		So.ln("작성일 : " + time);
		So.ln("내용 : " + content);
		So.ln("[조회수 : "+ this.hit + " ]");
		So.line();


		
	}
}