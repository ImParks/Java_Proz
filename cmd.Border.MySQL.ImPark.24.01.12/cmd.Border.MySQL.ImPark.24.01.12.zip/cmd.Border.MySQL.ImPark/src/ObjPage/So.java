package ObjPage;

public class So {

	public static void t(String s) {
		System.out.print(s);
	}

	public static void ln(String s) {
		System.out.println(s);
	}

	public static void line() {
		System.out.println("==========================================================");
	}

	public static void wn() { // 엔터 넣는함수
		System.out.println();
	}
}
