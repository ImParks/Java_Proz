package Part_13_Board;

public class Main {

public static void main(String[] args) {
	

	
	Home page = new Home();
	page.home();
	
}
}
