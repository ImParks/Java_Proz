package Part_13_Board;

import java.util.ArrayList;

public class Load {

	
	public static  ArrayList<Post> gather;

	public static void load() {
		gather = new ArrayList<>();	
	}
	
	
}
