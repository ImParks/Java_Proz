package com.MangoChat.Invite;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.MangoChat.MasterClass.Master_DA;

public class I_Dao extends Master_DA {

	public ArrayList<I_Dto> InviteList(String myUserNo) { // 알림창 조회 출력할떄
		ArrayList<I_Dto> inviteList = new ArrayList<I_Dto>();
		String sql = String.format("SELECT * FROM %s WHERE myUserNo = %s", DB_TABLE_INVITE, myUserNo);
		try {
			ResultSet rs = super.Query(sql);
			while (rs.next()) {
				if (rs.getInt("value") == 0) {
					inviteList.add(new I_Dto(rs.getString("no"), rs.getString("myUserNo"), rs.getString("freindUserNo"),
							rs.getString("value")));
				} else if (rs.getInt("value") == 1) {
					inviteList.add(new I_Dto(rs.getString("no"), rs.getString("myUserNo"), rs.getString("freindUserNo"),
							rs.getString("roomNo"), rs.getString("value")));
				}

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return inviteList;
	}

	public void freindInvite(I_Dto invite) { // 친구추가 메세지 보내기
		String sql = String.format("INSERT INTO %s(myUserNo,freindUserNo,value)VALUES(%s,%s,%s)", DB_TABLE_INVITE,
				invite.myUserNo, invite.freindUserNo, invite.value);
		update(sql);
		close();
	}

	public void roomInvite(I_Dto invite, String roomNo) { // 채팅방 초대 메세지 보내기
		String sql = String.format("INSERT INTO %s(myUserNo,freindUserNo,roomNo,value)VALUES(%s,%s,%s,%s)",
				DB_TABLE_INVITE, invite.myUserNo, invite.freindUserNo, roomNo, invite.value);
		update(sql);
		close();
	}

	public void invite(String myUserNo,String inviteNo) {
		String sql = null;
		I_Dto invite = inviteInfo(inviteNo);
		// 수락 누르면
		if (invite.value.equals("0")) { // 0이 친추 이거는 혁영이형이 채워주는걸로
			sql = String.format("INSERT INTO %s(myUserNo,)values()");

		} else if (invite.value.equals("1")) { // 방 초대
			sql = String.format("INSERT INTO %s(myUserNo,roomNo) values (%s,%s)", DB_TABLE_JOIN, myUserNo,
					invite.roomNo);
		}
		update(sql);
		close();
		inviteDel(inviteNo);
	}
	
	public void inviteDel(String inviteNo) {
		String delSql = String.format("DELETE FROM %s WHERE no = %s", DB_TABLE_INVITE, inviteNo);
		update(delSql);
		close();
	}

	private I_Dto inviteInfo(String inviteNo) {
		I_Dto invite = null;
		String sql = String.format("SELECT * FROM %s WHERE no = %s",DB_TABLE_INVITE,inviteNo);
		try {
			ResultSet rs = Query(sql);
			rs.next();
			int value = rs.getInt("value");
			if (value== 0) {
			invite = new I_Dto(rs.getString("no"),rs.getString("myUserNo"),rs.getString("freindUserNo"),rs.getString("value"));
			} else if(value == 1) {
				invite = new I_Dto(rs.getString("no"),rs.getString("myUserNo"),rs.getString("freindUserNo"),rs.getString("roomNo"),rs.getString("value"));
			}
		}catch (SQLException e) {
			System.out.println(sql);
			e.printStackTrace();
		}finally {
			close();
		}
		
		return invite;
	}

}