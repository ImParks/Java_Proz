package com.peisia.controller;




import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.peisia.spring.dto.stockDto.Item;
import com.peisia.spring.dto.stockDto.ResponseDto;

import lombok.extern.log4j.Log4j;
@Log4j
@Controller
@RequestMapping("/stock/*")
public class WeatherController {
	
	@GetMapping("/list")							
	public String w(@RequestParam("likeItmsNm") String stockName ,Model m){							
		try {
            // 우리나라 공공 API
            // 인코딩 인증키
            String API_KEY = "i6XT0IhYDLJYOwvz%2BBZ16YJ66vXLq7fkILaimSUDO9cvc%2F6ber7LZj2UpKF3w0pcJjoBBb%2BUpR2yGgCwnwoueQ%3D%3D";

            // 받아온 값 UTF-8로 인코딩
            String encodedStockName = URLEncoder.encode(stockName, StandardCharsets.UTF_8.toString());

            // API URL 생성
            String API_URL = "http://apis.data.go.kr/1160100/service/GetStockSecuritiesInfoService/getStockPriceInfo?serviceKey="
                    + API_KEY + "&likeItmsNm=" + encodedStockName + "&resultType=json&beginBasDt=20240305";

            RestTemplate restTemplate = new RestTemplate();
            // * 주의 * https 아님 http 임. https 는 인증관련 복잡한 처리를 해야함.
            URI uri = new URI(API_URL);
            log.info("==============================오류" + API_URL);

            ResponseDto re = restTemplate.getForObject(uri, ResponseDto.class);
   
            m.addAttribute("stock", re.response.body.items.item);

        } catch (UnsupportedEncodingException | URISyntaxException e) {
            e.printStackTrace();
            // 예외 처리: 실패한 경우에 대한 로깅 또는 사용자에게 알림 등을 추가할 수 있습니다.
            // 아래의 코드는 로깅만 하는 예시입니다.
            log.error("Failed to process the request: " + e.getMessage());
        }

        return "/stockInfo";
	}							
								
}
