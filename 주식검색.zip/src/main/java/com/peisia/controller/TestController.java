package com.peisia.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.peisia.service.TestService;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/test/*")
//@AllArgsConstructor
@Controller
public class TestController {
		
	@Setter(onMethod_ = @Autowired)
	private TestService service;
	
	@GetMapping("/getOnePlusTwo")
	public String getOnePlusTwo(Model model) {
//	public void getOnePlusTwo() {
		
		String one = service.getOne();
		String two = service.getTwo();
		Integer sum = Integer.parseInt(one) + Integer.parseInt(two); 
		service.count();
		int count = service.getCount5();
		log.info("(여기 컨트롤러임) 1 더하기 2는 = " + sum);
		log.info("현재 방문자 수는 " + count + "입니다.");
		model.addAttribute("sum",sum);
		model.addAttribute("count",count);
		model.addAttribute("text",service.getTextList());
		return "/test/getOnePlusTwo";
	}
	
	
	@GetMapping("/reset")
	public String reSetCount(Model model) {
		log.info("-------------------------");
	service.reset();
	return "redirect:/test/getOnePlusTwo";
	}
	
	@GetMapping("/text")
	public String text(@RequestParam(name = "chat")String chat,Model model) {
		log.info("글자임");
		service.text(chat);
		return "redirect:/test/getOnePlusTwo";
	}
	
	@GetMapping("/del")
	public String del(@RequestParam(name = "chatNo")String chatNo,Model model) {
		log.info("삭제임");
		service.del(chatNo);
		return "redirect:/test/getOnePlusTwo";
	}
	
	
}
