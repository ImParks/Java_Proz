package com.peisia.mapper;

import java.util.ArrayList;

import com.peisia.spring.dto.TestDto;
//저장소? 필요할때 값을 불러오는역할
public interface TestMapper {
	// 인터페이스로 함수를 선언하면 다른파일에서 함수를 재정의할수있다. 상속 비슷한개념
	public TestDto getData1();
	public TestDto getData2();
	public TestDto getCount5();
	public void updateDate1();
	public void reset();
	public ArrayList<TestDto> getTextList();
	public void text(String chat);
	public void del(String chatNo);
}