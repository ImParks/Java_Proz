package com.peisia.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.peisia.mapper.TestMapper;
import com.peisia.spring.dto.TestDto;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
//@AllArgsConstructor
public class TestServiceImpl implements TestService{

	@Setter(onMethod_ = @Autowired)
	private TestMapper mapper;	
	
	@Override
	public String getOne() {
		log.info("test===========");
		TestDto tvo = mapper.getData1();
		String one = tvo.getStr_data();
		return one;
	}

	@Override
	public String getTwo() {
		log.info("test===========");
		TestDto tvo = mapper.getData2();
		String two = tvo.getStr_data();
		return two;
	}
	
	@Override
	public int getCount5() {
		log.info("업데이트=========");
		TestDto td = mapper.getCount5();
		int count = td.getCount();
		return count;
	}
	@Override
	public void count() {
		mapper.updateDate1();
	}
	
	
	@Override
	public void reset() {
		log.info("리셋===========");
		mapper.reset();	
	}
	
	@Override
	public ArrayList<TestDto> getTextList(){
		return mapper.getTextList();
	}
	@Override
	public void text(String chat) {
		mapper.text(chat);
	}
	@Override
	public void del(String chatNo) {
		mapper.del(chatNo);
	}

}
