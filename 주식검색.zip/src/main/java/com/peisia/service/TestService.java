package com.peisia.service;

import java.util.ArrayList;

import com.peisia.spring.dto.TestDto;

public interface TestService {
	public String getOne();
	public String getTwo();
	public int getCount5();
	public void reset();
	public void count();
	public ArrayList<TestDto> getTextList();
	public void text(String chat);
	public void del(String chatNo);
}
