package com.peisia.spring.dto;

import lombok.Data;

@Data
public class TestDto {
	
	
	private int count;
	private int no;
private String Str_data;
	
	
}
