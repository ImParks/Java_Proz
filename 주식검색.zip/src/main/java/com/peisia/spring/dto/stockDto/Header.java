package com.peisia.spring.dto.stockDto;

public class Header { 
	public int resultCode;
	public String resultMsg;
}
