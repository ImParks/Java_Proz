package com.peisia.spring.dto;

import lombok.Data;

@Data
public class SearchDto {
 private String stockName="";
	
	
}
