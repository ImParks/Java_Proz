package com.peisia.spring.dto.stockDto;

import java.util.List;

import lombok.Data;
@Data
public class Items { 
	public List<Item> item;
}