package com.peisia.spring.dto.stockDto;

public class Response { 
	public Header header;
	public Body body;
}