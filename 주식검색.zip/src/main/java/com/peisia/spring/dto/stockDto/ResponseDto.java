package com.peisia.spring.dto.stockDto;

public class ResponseDto {

	public Response response;
}
