package com.peisia.spring.dto.stockDto;

public class Body { 
	public int numOfRows;
	public int pageNo;
	public int totalCount;
	public Items items;
}